<?php
    define('DIR_NAME', dirname(__DIR__));
    
    // autoload the autoloader file
    require_once (DIR_NAME.'/vendor/autoload.php');

    use poolgame\src\classes\functionsClass as func;
    use poolgame\src\classes\sessionClass as sessions;
    use poolgame\src\classes\templateClass as templates;
    use poolgame\src\classes\routeClass as routes;
    
    // instantiate the methods
    $functions = new func();
    $session = new sessions();
    $templates = new templates();
    $routerClass = new routes();

    // start a session
    $session->start();