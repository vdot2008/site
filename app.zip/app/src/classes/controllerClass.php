<?php


namespace poolgame\src\classes;

require_once('db.php');
abstract class controllerClass
{
    public $con;
    protected $host = DB_HOST; // your host name
    protected $username = DB_USER; // your user name
    protected $password = DB_PASS; // your password
    protected $db = DB_NAME; // your database name

    public function __construct()
    {
        $this->con = $this->connectDB();
    }

    protected function connectDB()
    {
        $con = mysqli_connect($this->host, $this->username, $this->password, $this->db) or die('Connection was interupted please try again later');
        mysqli_set_charset($con, "utf8mb4");
        return $con;
    }

    public function select(string $table, string $statement)
    {
        $condition = '';
        if (strlen($statement) > 0) {
            $condition = ' WHERE ' . $statement;
        }

        $statement = "SELECT * FROM $table $condition";
        $query = $this->fetchRows($statement);
        return $query;
    }

    public function fetchRows($statement)
    {
        $query = $this->query($statement);
        if ($this->count_rows($query) > 0) {
            $data = [];
            while ($rows = mysqli_fetch_assoc($query)) {
                $data[] = $rows;
            }
            return $data;
        } else {
            return '';
        }
    }

    public function query($statement)
    {
        $query = mysqli_query($this->con, $statement);
        return $query;
    }

    // Select Statement

    public function count_rows($statement)
    {
        return $query = mysqli_num_rows($statement);
    }

    // Select Join

    public function join_select(string $table, string $alias, string $join, string $statement)
    {
        $condition = '';
        if (strlen($statement) > 0) {
            $condition = ' WHERE ' . $statement;
        }

        $join_statement = '';
        if (strlen($join) > 0) {
            $join_statement = " $join ";
        }

        if (strlen($alias) > 0) {
            $alias = $alias;
        } else {
            $alias = ' * ';
        }

        $statement = " SELECT $alias FROM $table $join_statement $condition ";
        $query = $this->fetchRows($statement);
        return $query;
    }

    // insert statement
    public function insert(string $table, array $data, $true = false)
    {
        $key = array_keys($data);
        $val = array_values($data);
        $sql = "INSERT INTO $table (" . implode(', ', $key) . ") " . "VALUES ('" . implode("', '", $val) . "')";

        if ($this->query($sql) == true) {
            return mysqli_insert_id($this->con);
        }
    }

    // multipule insert values
    public function multiple_insert(string $table, array $keys, array $values)
    {
        $sql = "INSERT INTO $table (" . implode(', ', $keys) . ") VALUES ";
        $q = $split_data = '';
        $count = count($values);
        for($i=0; $i < $count; $i++) {
            $split_data .= "('".implode("','", array_values($values[$i]))."'), ";
        }
        $sql .= substr($split_data, 0, -2);
        if ($this->query($sql) == true) {
            return '1';
        }
    }

    public function delete(string $table, string $subQuery)
    {
        $sql = "DELETE FROM $table WHERE $subQuery";
        $query = $this->query($sql);
        if ($query == true) {
            return 1;
        }
        return '';
    }

    public function update(string $table, string $condition, array $data)
    {
        $key = array_keys($data);
        $val = array_values($data);
        $stmt = '';

        foreach ($data as $key => $values) {
            $stmt .= trim($key . '=' . '"' . $values . '"') . ',';
        }

        $sql = "UPDATE $table SET " . substr($stmt, '0', '-1') . " WHERE $condition ";
        $query = $this->query($sql);
        if ($query == true) {
            return 1;
        }
        return mysqli_error($this->con);


        // $cols = array();

        // foreach($data as $key=>$val) {
        //     if($val != NULL) // check if value is not null then only add that colunm to array
        //     {
        //        $cols[] = "$key = '$val'";
        //     }
        // }
        // $sql = "UPDATE $table SET " . implode(', ', $cols) . " WHERE $where";


    }

}
