<?php

namespace poolgame\src\classes;

class functionsClass extends controllerClass
{
    // filter inputs

    public function add_slashes($string)
    {
        return $this->con->real_escape_string(addslashes(trim($string)));
    }

    // html special characters
    public function filter_output($string)
    {
        return htmlspecialchars($string);
    }

    // error modal
    public function errorBlock($message)
    {
        $output = '
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title m-0">Failed</h5>
                    <button class="close btn-close closeModal" id="" type="button" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">' . $message . '</div>
                <div class="modal-footer">
                    <div class="d-grid">
                        <button class="btn btn-danger btn-sm closeModal" type="button" data-bs-dismiss="modal">Cancel</button>
                    </div>
                </div>
            </div>
        ';
        return $output;
    }

    // success modal body
    public function successBlock($message)
    {
        $output = '
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title m-0">Successful Response</h5>
                    <button class="close btn-close closeModal" id="reload" type="button" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">' . $message . '</div>
                <div class="modal-footer">
                    <button class="btn btn-sm btn-success closeModal" id="reload"
                        type="button" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        ';
        return $output;
    }

    public function modal($title, $message)
    {
        $output = '
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title m-0">'.ucwords($this->filter_output($title)).'</h5>
                    <button class="close btn-close closeModal" type="button" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">' . $message . '</div>
                <div class="modal-footer">
                    <button class="btn btn-sm btn-success closeModal" type="button" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        ';
        return $output;
    }
 
    public function api($param)
    {
        $host = $this->baseUrl;
        $key = $this->key;

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => $host . $param . '&timezone=Africa/Lagos',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => array(
                "x-apisports-key: {$key}"
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);
        if ($err) {
            return '';
        } else {
            return $response;
            //             return json_decode($response, true);
        }
        curl_close($curl);
    }

    // request for the api-football api

    public function validate_phone_number($phone)
    {
        $pattern = '/0[0-9]{10}/';
        if (preg_match($pattern, $phone)) {
            return $phone;
        } else {
            return '';
        }
    }

    // validate phone number

    public function logout($sID, $sType, $url)
    {
        if (isset($sID, $sType) && !empty($sID) || !empty($sType)) {
            unset($_SESSION[$sID]);
            unset($_SESSION[$sType]);
            $_SESSION = array();
            if (session_destroy()) {
                return header("LOCATION:{$url}");
            }
        }
    }

    public function redirect($url)
    {
        return header("LOCATION:{$url}");
    }

    /* * SESSION DECLARATIONS */

    public function content_type($string)
    {
        return header("Content-type:{$string}");
    }

    // content type

    public function sanitize_input($method, $string_var)
    {
        if ($this->filter(filter_input($method, $string_var, FILTER_SANITIZE_SPECIAL_CHARS))) :
            return $this->filter(filter_input($method, $string_var, FILTER_SANITIZE_SPECIAL_CHARS));
        elseif ($this->filter(filter_input($method, $string_var, FILTER_SANITIZE_EMAIL))) :
            if ($this->filter(filter_input($method, $string_var, FILTER_VALIDATE_EMAIL))) :
                return $this->filter(filter_input($method, $string_var, FILTER_VALIDATE_EMAIL));
            endif;
        elseif ($this->filter(filter_input($method, $string_var, FILTER_DEFAULT ))) :
            return $this->filter(filter_input($method, $string_var, FILTER_DEFAULT ));
        endif;
    }

    // sanitize post and get post data

    public function filter($string)
    {
        $string = $this->con->real_escape_string(trim($string));
        return $string;
    }

    // generating random string
    public function random_string($length)
    {
        $allcharstrings = uniqid() . time() . 'abcdefghijklmnopqrstuvwxyzABCDEFGHILJKLMNOPQRSTUVWXYZ1234567890';
        $charArray = str_split($allcharstrings);
        $result = "";
        for ($i = 0; $i < $length; $i++) {
            $randIndex = array_rand($charArray);
            $result = $result . $charArray[$randIndex];
        }
        return $result;
    }

    /* * creating unique id */
    public function uniqueID($length)
    {
        $output = "";
        $strings = uniqid() . time() . 'ABCDEFGHILJKLMNOPQRSTUVWXYZ1234567890';
        $charArray = str_split($strings);

        for ($i = 0; $i < $length; $i++) {
            $randIndex = array_rand($charArray);
            $output = $output . $charArray[$randIndex];
        }
        return $output;
    }

    // check random number
    public function check_and_generate_id($tbl, $column, $length){
        $val = $this->uniqueID($length);
        // check the database 
        $statement = " `".trim($column)."` = '".trim($val)."' ";
        $query = $this->select($tbl, $statement);
        if(!empty($query)){
            $this->check_and_generate_id($tbl, $column, $length);
        }

        return $val;
    }

    public function check_db($tbl, $data, $subQuery = false, $options){
        $stmt = '';
        $apperande = ' OR ';
        if(!empty($options)) {
            $apperande = ' AND ';
        }
        foreach ($data as $key => $values) {
            $stmt .= trim( "`".$key."`" . '=' . '"' . mysqli_real_escape_string($this->con, $values) . '"') . $apperande;
        }

        $statement = substr($stmt, '0', '-4');
        
        // check for subquery
        if(isset($subQuery) && !empty($subQuery)) {
            $statement .= ' AND '.$subQuery;
        }

        $query = $this->select($tbl, $statement);
        if (!empty($query)) {
            return 1;
        }
        return 0;
    }

    // start a session
    public function start_Session()
    {
        session_start();
    }

    // assigning a session as ID
    public function SessionID()
    {
        return $this->hashing('encrypt', "id");
    }

    // assigning a session as TYPE

    public function hashing($action, $string)
    {
        $output = "";
        $encrypt_method = "AES-256-CBC";
        $secret_key = 'eaiYYkYTysia2lnHiw0N0vx7t7a3kEJVLfbTKoQIx5o';
        $secret_iv = 'eaiYYkYTysia2lnHiw0N0';
        // hash
        $key = hash('sha256', $secret_key);

        // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
        $iv = substr(hash('sha256', $secret_iv), 0, 16);
        if ($action == 'encrypt') {
            $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
            $output = base64_encode($output);
        } else if ($action == 'decrypt') {
            $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
        }
        return $output;
    }

    // hashing system

    public function SessionType()
    {
        return $this->hashing('encrypt', "type");
    }

    // dAE TIME AGO FUNCTION
    public function time_ago($date)
    {
        date_default_timezone_set('Africa/Lagos');
        if (empty($date)) {
            return "No date provided";
        }
        $periods = array("Sec", "Min", "Hr", "Day", "Week", "Month", "Year", "Decade");
        $lengths = array("60", "60", "24", "7", "4.35", "12", "10");
        $now = time();
        $unix_date = strtotime($date);
        // check validity of date
        if (empty($unix_date)) {
            return "Bad date";
        }
        // is it future date or past date
        if ($now > $unix_date) {
            $difference = $now - $unix_date;
            $tense = "";
        } else {
            $difference = $unix_date - $now;
            $tense = "";
        }
        for ($j = 0; $difference >= $lengths[$j] && $j < count($lengths) - 1; $j++) {
            $difference /= $lengths[$j];
        }
        $difference = round($difference);

        if ($difference != 1) {
            $periods[$j] .= "s";
        } else {
            $difference = '1';
        }
        if (strtolower($periods[$j]) == 'day') {
            return "Yesterday";
        } else {

            return "<span>$difference</span> " . strtolower($periods[$j]) . " {$tense}";
        }
    }

    // round the the upper 1000
    public function roundUp($num, $divisor)
    {
        $diff = $num % $divisor;
        if ($diff == 0) {
            return $num;
        } else {
            return $num - $diff + $divisor;
        }
    }

    // round down to the lower 1000
    public function roundDown($num, $divisor)
    {
        $diff = $num % $divisor;
        return $num - $diff;
    }

    public function get_ip_address(){
        foreach (array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR') as $key){
            if (array_key_exists($key, $_SERVER) === true){
                foreach (explode(',', $_SERVER[$key]) as $ip){
                    $ip = trim($ip); // just to be safe
    
                    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false){
                        return $ip;
                    }
                }
            }
        }
    }

    public function locationIP(){ 	
        $ip = $this->get_ip_address();
        $apiKey = 'RzxUZg4qrqs9Clgs5rDdoIpZ1YisphJd6ic2Lchb';
        $url = "https://api.ipbase.com/v2/info?ip=$ip&apikey=$apiKey";
    
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    
        $resp = curl_exec($curl);
        if($resp === FALSE) { 
            $msg = curl_error($curl); 
            curl_close($curl); 
            return ''; 
        } 
        curl_close($curl);
    
        // Retrieve IP data from API response 
        $ipData = json_decode($resp, true); 
         
        // Return geolocation data 
        return !empty($ipData) ? $ipData:false; 
    }    

    public function getPath(){
        $path = $_SERVER['REQUEST_URI'] ?? '/';
        $pos = strpos($path, $_GET['page']);
        if($pos === false) {
            return $path;
        }

        return substr($path, 0 , $pos);
    }

}
