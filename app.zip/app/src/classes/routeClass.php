<?php

namespace poolgame\src\classes;

class routeClass
{
    private $url = [];
    private $templatePath = '';
    public $page_file = '';

    /*
     * $server_request = $_SERVER["QUERY_STRING"];
        print $needle = 'page=';
        print $str = substr($text, strpos($text, $needle) + strlen($needle)) .'<br><br>';
    */

    // Construct for the router
    public function __construct()
    {
        $url = $this->geturl();
        if (isset($url[0])) {
            $this->page_file = strtolower($url[0] . '.php');
        }
    }

    // Get the GET PARAM
    public function geturl(){
        
        if(isset($_GET['page'])) {
            $url = rtrim($_GET['page'], '/');
            $url = filter_var($url, FILTER_SANITIZE_URL);

            $url = explode("/", $url);
            return $url;
        }
    }

}