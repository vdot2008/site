<?php

namespace poolgame\src\classes;

class sessionClass
{
    private $set_session_flag = false;

    // start a session
    public function start()
    {
        if ($this->set_session_flag == false) {
            session_start();
            $this->set_session_flag = true;
        }
    }

    // Set a Session
    public function setCookie($key, $value)
    {
        $_COOKIE[$key] = $value;
    }

    // Get session data
    public function getCookie($key, $array = false)
    {
        if ($array == true) {
            if (isset($_COOKIE[$key][$array])) {
                return $_COOKIE[$key][$array];
            }
        } else {
            if (isset($_COOKIE[$key])) {
                return $_COOKIE[$key];
            }
        }
        return false;
    }

    // Set a Session
    public function setSession($key, $value)
    {
        $_SESSION[$key] = $value;
    }
    // Get session data
    public function getSession($key, $array = false)
    {
        if ($array == true) {
            if (isset($_SESSION[$key][$array])) {
                return $_SESSION[$key][$array];
            }
        } else {
            if (isset($_SESSION[$key])) {
                return $_SESSION[$key];
            }
        }
        return false;
    }

    // Append to a session
    public function add_to_session($session, $array)
    {
        if (!empty($array) && is_array($array)) {
            foreach ($array as $key => $vals) {
                $_SESSION[$session][$key] = $vals;
            }
        }
    }

    // display session data
    public function showSession($key = false)
    {
        print '<pre>';
        if ($key == true) {
            if (isset($key)) {
                print_r($_SESSION[$key]);
            }
        } else {
            print_r($_SESSION);
        }
        print '</pre>';
    }

    // destroying a session
    public function destroySession($key = false)
    {
        if ($this->set_session_flag == true) {
            if ($key == true) {
                if (isset($key)) {
                    session_destroy();
                    return '1';
                }
            } else {
                $_SESSION = array();
                session_destroy();
                return '1';
            }
        }
    }

}
