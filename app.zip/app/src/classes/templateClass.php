<?php

    namespace poolgame\src\classes;

    class templateClass {

        // get the template 
        public function file_get_content($layout) {
            return $get_content = file_get_contents(DIR_NAME . "/app/src/templates/$layout");
        }

        // clear cache and return the page
        public function renderPage(array  $array_placeholder, array $array_contents, $contentURL) {
            $get_content = $this->file_get_content($contentURL);
            $content = str_replace($array_placeholder, $array_contents, $get_content);
            return $this->renderOuput($content);
        }

        public function renderOuput($content) 
        {
            ob_start();
            $pageContent = $content;
            ob_get_clean();

            return $pageContent;
        }

    }
