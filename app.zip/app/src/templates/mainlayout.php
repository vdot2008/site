<!DOCTYPE html>
<html lang="en-US">
    <head>
        <title>{{title}}</title>
        <meta http-equiv="Expires" content="Tue, 01 Jan 1995 12:12:12 GMT">
        <meta http-equiv="Pragma" content="no-cache">

        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">         
        <meta name="description" content="A mobile website betting coupon pool app">
        <meta name="keywords" content="season,week,europe,africa,global,meri,merry,pool,coupon,facebook,google,instagram,bing,bingo,gambling, game,bet,soccer,prediction,website,app,world,internet">
        
        <link rel="stylesheet" href="public/assets/libs/bootstrap/css/bootstrap.min.css" />
        <link rel="stylesheet" href="public/assets/css/animate.min.css" />
        <link rel="stylesheet" href="public/assets/css/remixicons/remixicon.css" />
        <link rel="stylesheet" href="public/assets/css/styles.css?version=0.155" />
    </head>
    <body>

        <script type="text/javascript" src="public/assets/js/jquery.js"></script>
        <script type="text/javascript" src="public/assets/js/validate.min.js"></script>

        <div class="mainWrapper">
            
            <div class="pageHeader">
                <div id="logo"> 
                    <a href="#" class="d-flex align-items-center">
                        <div id="" class="d-flex align-items-center"><img src="./assets/img/logo.png" ></div>MERI GLOBAL
                    </a>
                </div>
            </div>

            <div class="pageBody push-f-t">
                {{content}}
            </div>

        </div>

        <!-- The Modal -->
        <div class="modal fade" id="modal_container" tabindex="-1" aria-labelledby="modal_containerLabel" aria-hidden="true">
            <!--  modal-dialog-scrollable modal-fullscreen-sm-down -->
            <!-- modal-dialog-centered -->
            <div id="modal-dialog" class="modal-dialog modal-dialog-centered "></div>
        </div>

        <script type="text/javascript" src="public/assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script type="text/javascript" src="public/assets/js/popper.js"></script>
        <script type="text/javascript" src="public/assets/js/moment.js"></script>
        <script type="text/javascript" src="public/assets/js/bootbox.all.min.js"></script>
        <script type="text/javascript" src="public/assets/js/main.js"></script>

    </body>
</html>