<!-- <!DOCTYPE html>
<html lang="en-US">
    <head>
        <title>{{title}}</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <link rel="stylesheet" href="public/assets/css/styles.css" />
    </head>
    <body> -->

        <div id="ticket" class="ticket">
            {{content}}
            <small class="centered">{{footer}}</small>
        </div>
        <script src="//cdnjs.cloudflare.com/ajax/libs/pdf.js/2.8.335/pdf.min.js"></script>
<script type="text/javascript">
    pdfjsLib.GlobalWorkerOptions.workerSrc = "//cdnjs.cloudflare.com/ajax/libs/pdf.js/2.8.335/pdf.worker.min.js";
</script>

    <!-- </body>
</html> -->

<!--
<script type="text/javascript">
    function PrintElem(elem){
        var mywindow = window.open('', 'PRINT', 'height=auto,width=auto');

        // mywindow.document.write(
        //     `<html lang="en">
        //     <meta name="viewport" content="width=device-width, initial-scale=1.0">
        //     <head><title></title>`
        // );
        // mywindow.document.write(`</head><body>`);
        mywindow.document.write(document.getElementById(elem).innerHTML);
        // mywindow.document.write(
        //     `</body></html>`
        // );

        mywindow.document.close(); // necessary for IE >= 10
        mywindow.focus(); // necessary for IE >= 10*/

        mywindow.print();
        mywindow.close();

        return true;
    }
    PrintElem('ticket')
</script>

