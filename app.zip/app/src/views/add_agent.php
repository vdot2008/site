<?php

    // check if session is admin


    $content = '
        
        <div class="container-fluid">

            <a href="menus" class="backNav d-flex align-items-center justify-content-center">Menu</a>

            <div class="row">
                <div class="col-12">
                    <div class="card shadow-sm mb-3">
                        <div class="card-header text-center"><h3 class="card-title mb-0">Create Agent</h3></div>
                        <div class="card-body">
                            <form id="addagent_form" class=" p-3 bg-white" enctype="multipart/form-data">
                        
                                <div class="form-group mb-3 col-12 border-bottom">
                                    <label for="agent_name" class="form-label">Agent Name</label>
                                    <input type="text" class="form-control mb-3 " name="agent_name" id="agent_name" placeholder="Name of Agent:">
                                </div>   

                                <div class="form-group col-12 mb-3 ">
                                    <label for="agent_no" class="form-label">Agent Number</label>
                                    <input type="text" class="form-control" name="agent_no" id="agent_no" placeholder="Eg: 0001">
                                </div>

                                <div class="d-grid">
                                    <button type="submit" class="btn btn-success shadow-sm" id="agentBtn">Add Agent</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        
    ';

    // render the page content 
    print $templates->renderPage(['{{title}}', '{{content}}'], ['Merry Global - Create Season', $content], 'mainlayout.php');