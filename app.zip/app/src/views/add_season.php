<?php

    // check if session is admin


    $content = '
        <script type="text/javascript" src="public/assets/libs/datetimepicker/picker.js"></script>
        <link rel="stylesheet" href="public/assets/libs/datetimepicker/picker.css" />
        <div id="dtBox"></div>

        <div class="container-fluid">

            <a href="menus" class="backNav d-flex align-items-center justify-content-center">Menu</a>

            <div class="row">
                <div class="col-12">
                    <div class="card shadow-sm mb-4">
                        <div class="card-header"><h3 class="card-title mb-0">Add Season</h3></div>
                        <div class="card-body">
                            <form id="addseason_form" class=" bg-white" enctype="multipart/form-data">
                        
                                <div class="form-group mb-3 col-12 border-bottom">
                                    <label for="" class="form-label">Season Title</label>
                                    <input type="text" class="form-control mb-3 " name="season_name" id="season_name" placeholder="Name of the season:">
                                </div>
                                
                                <div class="row">
                                    <div class="form-group mb-3 col-6">
                                        <label for="" class="form-label">Start Date</label>
                                        <input type="text" class="form-control" name="start_date" id="start_date" style="cursor: pointer" data-field="datetime" data-format="dd-MMM-yyyy hh:mm:ss AA" required readonly placeholder="">
                                    </div>
                                    
                                    <div class="form-group mb-3 col-6">
                                        <label for="" class="form-label">End Date</label>
                                        <input type="text" class="form-control" name="end_date" id="end_date" style="cursor: pointer" data-field="datetime" data-format="dd-MMM-yyyy hh:mm:ss AA" required readonly placeholder="">
                                    </div>

                                    <small class="col-12 text-muted mb-2">Note: Activate only if you want to set season as current season</small>
                                    
                                </div>                                

                                <div class="form-group mb-3 border-bottom"></div>

                                <div class="row mb-3">
                                    <div class="form-group col-8 mb-3 ">
                                        <label for="week_prefix" class="form-label">Week Prefix</label>
                                        <input type="text" class="form-control" name="week_prefix" id="week_prefix" placeholder="Eg: Week">
                                    </div>
                                    <div class="form-group col-4 mb-3 ">
                                        <label for="week_count" class="form-label">Total</label>
                                        <input type="text" class="form-control" name="week_count" id="week_count" placeholder="0">
                                    </div>
                                </div>

                                <div class="d-grid">
                                    <button type="submit" class="btn btn-success shadow-sm" id="seasonBtn">Create Season</button>
                                </div>
                            </form>
                        </div>
                    </div>                    
                </div>
            </div>
        </div>
    ';

    // render the page content 
    print $templates->renderPage(['{{title}}', '{{content}}'], ['Meri Global - Create Season', $content], 'mainlayout.php');