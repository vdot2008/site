<?php

$content = '

  <div class="container-fluid pt-2">

      <a href="menus" class="backNav d-flex align-items-center justify-content-center">Menu</a>

      <div class="row">
        <div class="col-6 col-sm-4 col-md-3">
          <div class="mainNavs d-flex justify-content-center align-items-center"><a href="add_agent" class=" d-flex justify-content-center align-items-center flex-column bg-primary border-1 border-primary"><i class="ri ri-archive-drawer-fill"></i><span>Add Agent</span></a></div>
        </div>
        <div class="col-6 col-sm-4 col-md-3">
          <div class="mainNavs d-flex justify-content-center align-items-center"><a href="all_agent" class=" d-flex justify-content-center align-items-center flex-column bg-info border-1 border-info"><i class="ri ri-user-2-fill"></i><span>All Agents</span></a></div>
        </div>
      </div>

  </div>

';


// render the page content 
print $templates->renderPage(['{{title}}', '{{content}}'], ['Meri Global - Agents', $content], 'mainlayout.php');
