<?php

    // check if session is admin
    $statement = "";
    $query = $functions->select('users', $statement);

    $tr = '';
    if(!empty($query))
    {
        foreach ($query as $key => $value) {
            # code...
            $tr .= '
                <tr id="'.$functions->filter_output($value['agent_id']).'">
                    <td>
                        <div class="d-flex align-items-center">
                            <div class="btn-group btn-group-sm">
                                <button type="button" id="remove_agent_'.$functions->filter_output($value['agent_id']).'" data-id="'.$functions->filter_output($value['agent_id']).'" class="btn btn-danger btn-sm p-1 pt-0 pb-0"><i class="ri ri-delete-bin-3-fill"></i></button>
                            </div>
                            <p class="ps-3 mb-0">'.$functions->filter_output($value['agent_no']).'</p>
                        </div>
                    </td>
                </tr>
            ';
        }
    }

    $content = '
        
        <div class="container-fluid">

            <a href="menus" class="backNav d-flex align-items-center justify-content-center">Menu</a>

            <div class="row">
                <div class="col-12">
                    
                    <div class="table-responsive">
                        <table id="addagent_form" class="table table-striped table-condense table-bordered">
                            <thead>
                                <tr><th class="">All Agents</th></tr>
                            </thead>
                            <tbody>'.$tr.'</tbody>
                        </table>
                    </div>
                    
                </div>
            </div>
        </div>
        
    ';

    // render the page content 
    print $templates->renderPage(['{{title}}', '{{content}}'], ['Merry Global - Create Season', $content], 'mainlayout.php');