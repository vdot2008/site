<?php
    $lists = '';
    $alias     = ' `s`.*, `w`.*, `r`.*, `t`.*, 
                    (SELECT COUNT(ticket_id) FROM `ticket` AS `tt` WHERE `tt`.`ticket_type` = "child" AND `tt`.`parent_id` = `t`.`ticket_id` ) AS `total` ';
    $join      = ' AS `s` JOIN `weeks` AS `w` ON `s`.`season_id` = `w`.`season_id` AND `w`.`status` = "active" 
                   LEFT JOIN `results` AS `r` ON `r`.`season_id` = `s`.`season_id` AND `r`.`week_id` = `w`.`weeks_id` 
                   JOIN `ticket` AS `t` ON `t`.`season_id` = `s`.`season_id` AND `t`.`week_id` = `w`.`weeks_id` AND `t`.`ticket_type` = "parent" ';
    $statement = ' `s`.`status` = "active" ';
    $query = $functions->join_select('season', $alias, $join, $statement);
    if(!empty($query)) {
        foreach ($query as $key => $value) {
            $totals = '';
            if(!empty($value['total'])) {
                $totals = '<span class="badge bg-primary rounded-pill">'.$functions->filter_output($value['total']).'</span>';
            }
            # <span class="badge bg-primary rounded-pill">12</span>
            $lists .= '<li class="list-group-item"><a href="view_ticket?tickid='.$functions->hashing('encrypt', $value['ticket_no']).'"><small class="text-muted">Ticket #:</small> '.$functions->filter_output($value['ticket_no']). ' &nbsp; '. $totals. '</a></li>';
        }
    }

    $content = '
        <div class="container-fluid">

            <a href="menus" class="backNav d-flex align-items-center justify-content-center">Menu</a>


            <div class="row">
                <div class="col-12">
                    <ul class="list-group list-group-numbered">'.$lists.'</ul> 
                </div>
            </div>
        </div>
    ';

    // render the page content 
    print $templates->renderPage(['{{title}}', '{{content}}'], ['MerryGlobal - Win confirm', $content], 'mainlayout.php');