<?php
    $lists = '';
    $alias     = ' `s`.*, `w`.* ';
    $join      = ' AS `s` JOIN `weeks` AS `w` ON `s`.`season_id` = `w`.`season_id` 
                   LEFT JOIN `results` AS `r` ON `r`.`season_id` = `s`.`season_id` AND `r`.`week_id` = `w`.`weeks_id` ';
    $statement = ' `s`.`status` = "active" ORDER BY `w`.`weeks_id` ASC ';
    $query = $functions->join_select('season', $alias, $join, $statement);
    if(!empty($query)) {
        foreach ($query as $key => $value) {
            $active = $badge = " ";
            if($value['status'] === 'active') {
                $active = ' bg-light text-secondary';
                $badge = '<small><span  class="badge bg-info">Status: '.$functions->filter_output(ucwords($value['status'])). '</span></small>';
            }
            # <span class="badge bg-primary rounded-pill">12</span>
            $lists .= '<li class="list-group-item '.$active.'">
                        <a href="week_detail?wid='.$functions->hashing('encrypt', $value['weeks_id']).'" class="d-flex align-items-center text-secondary" >
                            <img src="./assets/img/logo.png" style="max-width: 42px;" >
                            <div class="p-3 pt-1 pb-1">
                                <h4 class="card-title mb-0 text-uppercase"><small class="text-muted">#</small>'.$functions->filter_output(ucwords($value['week_title'])). ' </h4>
                                <small class="">Season: '.$functions->filter_output(ucwords($value['season_name'])). '</small><br>
                                '.$badge.'
                            </div>
                        </a>
                    </li>
                ';
        }
    }

    $content = '
            
        <div class="container-fluid">
            <a href="menus" class="backNav d-flex align-items-center justify-content-center">Menu</a>

            <div class="row">
                <div class="col-12">
                    <div class="card shadow-sm">
                        <div class="card-header bg-white text-secondary text-center"><h3 class="card-title mb-0">Confirm Wins</h3></div>
                        <ul class="list-group list-group-flush">'.$lists.'</ul>
                    </div>
                </div>
            </div>
        </div>
            
    ';

    // render the page content 
    print $templates->renderPage(['{{title}}', '{{content}}'], ['MerryGlobal - Win confirm', $content], 'mainlayout.php');