<?php

    $content = '
        <div class="container">
            <div class="row mt-5">
                <form class="col-sm-6 col-md-4 col-12 mx-auto" 
                    action="public/parser/addPos" 
                    id="add_pos" 
                    enctype="multipart/form-data">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title m-0">Add Pos</h3>
                        </div>
                        <div class="card-body">
                            <div class="form-group mb-3">
                                <label for="" class="col-label">POS ID</label>
                                <input type="text" class="form-control" name="pos_id" id="pos_id" placeholder="Enter POS ID">
                                <small class="helper-text"></small>
                            </div>
                            <div class="form-group mb-3">
                                <label for="" class="col-label">IMEI NUMBER</label>
                                <input type="text" class="form-control" name="imei" id="imei" placeholder="IMEI">
                                <small class="helper-text"></small>
                            </div>
                            <div class="form-group">
                                <label for="" class="col-label">Set Password</label>
                                <input type="password" class="form-control" name="password" id="password" placeholder="Add Password">
                                <small class="helper-text"></small>
                            </div>
                        </div>
                        <div class="card-footer">
                            <button type="submit" id="btn" class="btn btn-block btn-primary">Add Terminal</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    ';

    // render the page content 
    print $templates->renderPage(['{{title}}', '{{content}}'], ['MerryGlobal - Add Pos', $content], 'mainlayout.php');