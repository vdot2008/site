<?php
    $content = '
        <div class="container">
            <div class="row mt-5">
                <form class="col-sm-6 col-md-4 col-12 mx-auto" 
                    action="public/parser/auth" 
                    data-pos="'.$session->getCookie('posID').'"
                    id="login" enctype="multipart/form-data">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title m-0">Login Account</h3>
                        </div>
                        <div class="card-body">
                            <div class="form-group mb-4">
                                <label for="pos" class="col-label">Pos No</label>
                                <input type="text" class="form-control" name="pos" 
                                    id="pos" 
                                    value="'.$session->getCookie('posID').'" 
                                    disabled required>
                                <small class="helper-text"></small>
                            </div>
                            <div class="form-group mb-4">
                                <label for="username" class="col-label">Agent ID</label>
                                <input type="text" class="form-control" name="username" 
                                    id="username" placeholder="Your Agent ID" required>
                                <small class="helper-text"></small>
                            </div>
                            <div class="form-group">
                                <label for="" class="col-label">Password</label>
                                <input type="password" class="form-control" name="password" id="password" placeholder="Your Password" required>
                                <small class="helper-text"></small>
                            </div>
                        </div>
                        <div class="card-footer d-flex justify-justify-content-center flex-column">
                            <input type="hidden" class="form-control d-none" name="cookie_id" id="cookie_id" value="'.$session->getCookie('posID').'" required>
                            <button type="submit" id="btn" class="btn btn-block btn-primary">Log in</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    ';

    // render the page content 
    print $templates->renderPage(['{{title}}', '{{content}}'], ['MerryGlobal - Login', $content], 'mainlayout.php');