<?php

  date_default_timezone_set('Africa/Lagos');
  $cues = '';

  $alias = " `s`.*, `w`.*, `f`.* ";
  $join  = " AS `s` JOIN `weeks` AS `w` 
            ON `s`.`season_id` = `w`.`season_id` AND `w`.`status` = 'active' 
            JOIN `fixtures` AS `f` ON `f`.`season_id` = `s`.`season_id` AND `f`.`week_id` = `w`.`weeks_id` 
  ";
  // db statement filtering
  $statement = " `s`.`status` = 'active' ";
  // select from the current season
  $query = $functions->join_select("season", $alias, $join, $statement);
  if(!empty($query)) {
    foreach($query as $rows){

      $fadded = $disabled = '';
      $attr = 'isactive="true"';

      $id = $functions->filter_output($rows['fixture_id']);
      $numbering = $functions->filter_output($rows['row_number']);
      $start_date = $functions->filter_output($rows['start_time']);
      
      $db_time = strtotime(date('d-m-Y H:i:s', strtotime($start_date)));
      $date = strtotime(date('d-m-Y H:i:s'));

      $db_game_time = date('H:i:s');

      // disable if game time as already been reached
      // disable if time is 4:00pm
      if($db_time <= $date || ($db_game_time >= '16:00:00' && strtolower(date('l')) == 'saturday')) {
        $fadded   = ' fadded ';
        $disabled = ' disabled';
        $attr = ' isactive="false"';
      }

      if(strlen($rows['row_number']) < 2) {
        $numbering = $functions->filter_output($rows['row_number']);
      }

      $cues .= '
        <div class="col-xs-1-10 col-sm-1-10 col-md-1-10 col-lg-1-10 d-flex flex-column justify-content-center align-content-center">
          <input type="checkbox" name="numbers[]" id="numbers_'.$numbering.'" class="number_inputs" value="'.$numbering.'" '.$disabled.' '.$attr.' />
          <label class="numbers_balls '.$fadded.' d-flex flex-column justify-content-center align-content-center" id="label_'.$numbering.'" for="numbers_'.$numbering.'"><span class="ballText">'.$numbering.'</span></label>
        </div>
      ';
    }
  }


  $napNumbers = [3, 4, 5, 6];
  $napLists = '';
  for($i = 0; $i < count($napNumbers); $i++) 
  {
    $napLists .= '<option value="nap'.$napNumbers[$i].'" data-id="'.$napNumbers[$i].'">NAP'.$napNumbers[$i].'</option>';
  }


  $content = '

      <div class="container-fluid">

        <a href="menus" class="backNav d-flex align-items-center justify-content-center">Menu</a>

        <button id="basic">Print page</button>
        <p id="demo">here is the printing content</p>

        <script type="text/javascript" src="assets/libs/print/print.js"></script>
        <script type="text/javascript">
          $(\'#basic\').on("click", function () {
            $(\'#demo\').printThis({
              base: "https://jasonday.github.io/printThis/"
            });
          });
        </script>


        <div class="row">
          <div class="col-6 col-sm-6">
            <select id="gameMenus" name="" class="form-select">
              <option id="nap" value="nap" selected="selected">NAP</option>
              <option id="perm" value="perm">PERM</option>
            </select>
          </div>
          <div class="col-6 col-sm-6">
            <select id="gameMenusLists" name="" class="form-select text-uppercase">
              '.$napLists.'
            </select>
          </div>
        </div>    
        <div class="row mt-2">
          <div class="col-12">
            <div class="d-grid">
              <button type="button" class="btn btn-block btn-success" onclick="shuffle();"> Auto Pick</button>
            </div>
          </div>
        </div>
      </div>

      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card bg-transparent border-0">
              <div class="card-body p-0">
                <div class="show-balls text-center" id="show-balls"></div>
              </div>
              <div class="card-body p-0">
                <div class="">'.$cues.'</div>
              </div>
            </div>
          </div>
        </div>

        <div id="printer_wrap" class="d-none"></div>

      </div>

      <div class="pageFooter">
        <div class="container-fluid">

          <div class="row">
            <div class="col-12 col-sm-12">
              <div class="amt__wrapper">
                <div class="input-group mb-1">
                  <span class="input-group-text">&#8358;</span>
                  <input type="text" class="form-control disabled text-center" name="amount_input" id="amount_input" 
                        value="" placeholder="0.00" style="font-size: 18px;" disabled required>
                </div>
              </div>
            </div>

            <div class="col-12 col-sm-12">
              <div class="btn-group d-flex">
                <button type="button" id="addGame" class="btn btn-block btn-primary" >ADD</button>
                <button type="button" id="checkout" class="btn btn-block btn-success" ><span class="badge rounded-pill bg-light text-secondary fw-bolder"></span> Checkout</button>
                <button type="button" id="cancel" class="btn btn-block btn-danger" >Cancel</button>
              </div>
            </div>
          </div>

        </div>
      </div>
  ';


  // render the page content 
  print $templates->renderPage(['{{title}}', '{{content}}'], ['main index page', $content], 'mainlayout.php');
