<?php

$content = '
    <div class="container-fluid p-3">
        <div class="row">
            <div class="col-6 col-sm-4 col-md-3">
                <div class="mainNavs d-flex justify-content-center align-items-center"><a href="main" class=" d-flex justify-content-center align-items-center flex-column bg-info border border-1 border-info"><i class="ri ri-account-circle-fill"></i><span>Book</span></a></div>
            </div>
            <div class="col-6 col-sm-4 col-md-3">
                <div class="mainNavs d-flex justify-content-center align-items-center"><a href="confirm_wins" class=" d-flex justify-content-center align-items-center flex-column bg-success border border-1 border-success"><i class="ri ri-gift-2-fill"></i><span>Win Confirm</span></a></div>
            </div>
            <div class="col-6 col-sm-4 col-md-3">
                <div class="mainNavs d-flex justify-content-center align-items-center"><a href="#" class=" d-flex justify-content-center align-items-center flex-column bg-danger border border-1 border-danger"><i class="ri ri-delete-bin-4-fill"></i><span>Cancel Ticket</span></a></div>
            </div>
            <div class="col-6 col-sm-4 col-md-3">
                <div class="mainNavs d-flex justify-content-center align-items-center"><a href="reports" class=" d-flex justify-content-center align-items-center flex-column bg-light text-secondary border border-1 border-light"><i class="ri ri-ticket-2-fill"></i><span>Report</span></a></div>
            </div>
            <div class="col-6 col-sm-4 col-md-3">
                <div class="mainNavs d-flex justify-content-center align-items-center"><a href="search" class=" d-flex justify-content-center align-items-center flex-column bg-secondary border border-1 border-secondary"><i class="ri ri-file-search-fill"></i><span>Search Ticket</span></a></div>
            </div>
            <div class="col-6 col-sm-4 col-md-3">
                <div class="mainNavs d-flex justify-content-center align-items-center"><a href="settings" class=" d-flex justify-content-center align-items-center flex-column bg-warning border border-1 border-warning"><i class="ri ri-settings-2-fill"></i><span>Settings</span></a></div>
            </div>
            <div class="col-6 col-sm-4 col-md-3">
                <div class="mainNavs d-flex justify-content-center align-items-center"><a href="add_season" class=" d-flex justify-content-center align-items-center flex-column bg-primary border border-1 border-primary"><i class="ri ri-folder-add-fill"></i><span>Add Season</span></a></div>
            </div>
            <div class="col-6 col-sm-4 col-md-3">
                <div class="mainNavs d-flex justify-content-center align-items-center"><a href="seasons" class=" d-flex justify-content-center align-items-center flex-column bg-info border border-1 border-info"><i class="ri ri-archive-drawer-fill"></i><span>All Seasons</span></a></div>
            </div>
            <div class="col-6 col-sm-4 col-md-3">
                <div class="mainNavs d-flex justify-content-center align-items-center"><a href="agent" class=" d-flex justify-content-center align-items-center flex-column bg-info border border-1 border-info"><i class="ri ri-user-2-fill"></i><span>Agents</span></a></div>
            </div>
        </div>
    </div>
';


// render the page content 
print $templates->renderPage(['{{title}}', '{{content}}'], ['Meri Global - Menu', $content], 'mainlayout.php');
