<?php

    $pos_id       = mysqli_real_escape_string($functions->con, $session->getCookie('posID'));
    $agent_no     = mysqli_real_escape_string($functions->con, $session->getSession('pos_agent', 'agent_no'));            
    $agent_pos    = mysqli_real_escape_string($functions->con, $session->getSession('pos_agent', 'pos_id'));     
    $agent_tbl_id = mysqli_real_escape_string($functions->con, $session->getSession('pos_agent', 'id'));
    $data = '';

    $statement = " `ticket_type` = 'child' AND `agent_id` = '{$agent_tbl_id}' AND `pos_id` = '{$agent_pos}' ";
    $query = $functions->select('ticket', $statement);
    if(!empty($query))
    {
        $amount = array();
        foreach ($query as $key => $value) {
            # code...
            if(date('Y-m-d', strtotime($value['date_created'])) === date('Y-m-d')) {
                array_push($amount, $value['amount']);
            }
        }

        $t_amt = 0;
        if(!empty($amount)) {
            $t_amt = array_sum($amount);
        }
        $data = '
            <div id="details" class="card-body">
                <div class="row">
                    <div class="col-5"><h4>Agent ID:</h4></div>
                    <div class="col-7 text-end" style="font-size: 20px;">'.$agent_no.'</div>
                </div>
                <div class="row">
                    <div class="col-5"><h4>Teminal: </h4></div>
                    <div class="col-7 text-end" style="font-size: 20px;">'.$agent_pos.'</div>
                </div>
                <div id="reportWrap">
                    <div class="row">
                        <div class="col-5"><h4>Sales Date:</h4></div>
                        <div class="col-7 text-end" style="font-size: 20px;"><i class="ri ri-calendar-check-fill"></i> '.date('d/m/Y').'</div>
                    </div>
                    <div class="row">
                        <div class="col-5"><h4>Total:</h4></div>
                        <div class="col-7 text-end" style="font-size: 20px;">&#8358;'.number_format($t_amt, 0).'</div>
                    </div>
                </div>
                
            </div>
        ';
    }


    $content = '
        <link rel="stylesheet" href="public/assets/libs/datetimepicker/picker.css" />
        <div id="dtBox"></div>
        <script type="text/javascript" src="public/assets/libs/datetimepicker/picker.js"></script>

        <a href="menus" class="backNav d-flex align-items-center justify-content-center">Menu</a>

        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card shadow">
                        <div class="card-header text-center"><h2 class="mb-0 card-title">Sales Report</h2></div>
                        <div class="card-body">
                            <div class="input-group">
                                <span class="input-group-text"><i class="ri ri-calendar-check-fill"></i></span>
                                <input type="text" class="form-control" id="textbox" data-field="datetime" data-format="dd-MMM-yyyy hh:mm:ss AA" required readonly>
                                <button class="btn btn-success" id="" onclick="filterDate(\'textbox\', \'reportWrap\');" type="submit">Filter</button>
                            </div>
                        </div>
                        '.$data.'
                    </div>
                </div>
            </div>
        </div>
    ';

    // render the page content 
    print $templates->renderPage(['{{title}}', '{{content}}'], ['MerryGlobal - Win confirm', $content], 'mainlayout.php');