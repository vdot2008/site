<?php

    $content = '
        <div class="container-fluid">
            <a href="menus" class="backNav d-flex align-items-center justify-content-center">Menu</a>

            <div class="row">
                <div class="col-12">

                    <div class="input-group">
                        <input type="text" class="form-control text-center" id="textbox" placeholder="Search Ticket" required>
                        <button class="btn btn-secondary" id="srTicket" data-url="searchTicket" type="submit"><i class="ri ri-search-2-fill"></i></button>
                    </div>

                    <div id="result" class="card mt-3 shadow-sm d-none">
                        <div class="card-body"></div>
                    </div>

                </div>
            </div>
        </div>
    ';

    // render the page content 
    print $templates->renderPage(['{{title}}', '{{content}}'], ['Meri Global - Search Ticket', $content], 'mainlayout.php');