<?php
    $lists = '';
    $statement = " `status` = 'active' OR `status` = 'inactive' ";
    $query = $functions->select("season", $statement);
    if(!empty($query))
    {
        foreach($query as $rows){
            $active = '';
            $btn = '<button type="button" id="setSeason" data-id="'.$functions->filter_output($rows['season_id']).'" class="btn btn-sm btn-outline-secondary shadow-sm">Activate Season</button>';
            $label = '';
            if($rows['status'] === 'active') {
                $btn = '';
                $active = 'bg-light';
                $label = '<span class="badge bg-info">Status: '.$functions->filter_output($rows['status']).'</span>';
            }
            $lists .= '
                <li class="list-group-item '.$active.'">
                    <h5 class="mb-0 card-title"><small class="text-muted">Season#</small> '.$functions->filter_output(ucwords($rows['season_name'])).'</h5>
                    <small class="text-muted">Created: '.date("d/m/Y", strtotime($functions->filter_output($rows['date_create']))).'<br></small>
                    <small>'.$label.'</small>
                    <div class="d-flex align-content-center justify-content-between mt-1">
                        <a href="seasons_weeks?id='.$functions->filter_output($rows['season_id']).'" class="btn btn-secondary btn-sm shadow-sm">View Weeks</a> &nbsp; 
                        ' . $btn . '
                    </div>
                </li>                
            ';
        }        
    }
    $content = '        
        
        <div class="container-fluid">

            <a href="menus" class="backNav d-flex align-items-center justify-content-center">Menu</a>

            <div class="row">
                <div class="col-12">
                    
                    <ul class="list-group">
                        '.$lists.'
                    </ul> 
                    
                </div>
            </div>
        </div>
            
    ';

    // render the page content 
    print $templates->renderPage(['{{title}}', '{{content}}'], ['Merry Global - Set Week', $content], 'mainlayout.php');