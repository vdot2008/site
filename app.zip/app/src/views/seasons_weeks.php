<?php
    $lists = $td = '';
    if(isset($_GET['id'])) {
        $id = filter_var($_GET['id'], FILTER_SANITIZE_STRING);

        $alias = " s.*, w.*, `w`.`status` AS `w_status` ";
        $join = " AS `s` join `weeks` AS `w` ON `s`.`season_id` = `w`.`season_id` ";
        $statement = " `s`.`season_id` = '{$id}' ";

        $query = $functions->join_select("season", $alias, $join, $statement);
        if(!empty($query))
        {
            foreach($query as $rows){
                $active = $label = $class ='';
                $btn = '<button type="button" id="setWeek" data-id="'.$functions->filter_output($rows['weeks_id']).'" class="btn btn-sm btn-outline-secondary shadow-sm">Set</button>';
                if($rows['w_status'] === 'active') {
                    $btn = '';
                    $active = ' bg-light ';
                    $class  = ' text-white';
                    $label  = '<span class="badge bg-info">Status : '.ucwords($functions->filter_output($rows['w_status'])).'</span>';
                }
                $lists .= '
                    <li class="list-group-item '.$active.'">
                        <h5 class="mb-0 card-title"><small class="text-muted">#</small>'.$functions->filter_output(ucwords($rows['week_title'])).'</h5>
                        <small class="text-muted">Season:&nbsp;'.$functions->filter_output($rows['season_name']).'</small><br> 
                        <small>'.$label.'</small>
                        <div class="d-flex align-content-center justify-content-between mt-1">
                            <a href="weeks_fixtures?id='.$functions->filter_output($rows['weeks_id']).'" class="btn btn-secondary btn-sm shadow-sm">View Fixtures</a> &nbsp; 
                            ' . $btn . '
                        </div>
                    </li> ';
            }        
        }    
    }
    $content = '
        <div class="container-fluid">
            <a href="menus" class="backNav d-flex align-items-center justify-content-center">Menu</a>

            <div class="row">
                <div class="col-12">                    
                    <ul class="list-group">'.$lists.'</ul>                     
                </div>
            </div>
        </div>
    ';

    // render the page content 
    print $templates->renderPage(['{{title}}', '{{content}}'], ['Merry Global - Set Week', $content], 'mainlayout.php');