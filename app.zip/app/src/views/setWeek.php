<?php
    $bals = '';
    // check if session is admin
    $alias = " s.*, w.* ";
    $join = " AS `s` join `weeks` AS `w` ON `s`.`season_id` = `w`.`season_id` AND `w`.`status` = 'active' ";
    $statement = " `s`.`status` = 'active' ";

    $query = $functions->join_select("season", $alias, $join, $statement);
    if(!empty($query))
    {
        $bals .= '<div class="card mb-3">
            <div class="card-header"><h4 class="card-title mb-0">Set Week '.$functions->filter_output($query[0]['week_title']).' Fixtures Time</h4></div>
            <div class="card-body">
                <ul class="list-group list-group-flush">
        ';
        $num = 49;
        for($i = 1; $i <= $num; $i++) {
            $balUI = '<span class="numbers_balls active" style="margin: 0px;"><span class="ballText">'.$i.'</span></span>';
            $bals .= '
                <li class="list-group-item">
                    <div class="input-group mb-0 input-group-sm">
                        <span class="input-group-text">Ball &nbsp;'.$balUI.'</span>
                        <input type="text" class="form-control" name="gameTime[]" id="game_id_'.$i.'" data-field="datetime" data-format="dd-MMM-yyyy hh:mm:ss AA" readonly>
                    </div>
                </li>
            ';
        }
        $bals .= '
                        <li class="list-group-item">
                            <div class="d-grid">
                                <button type="button" 
                                    data-week="'.$functions->filter_output($query[0]['weeks_id']).'" 
                                    data-season="'.$functions->filter_output($query[0]['season_id']).'" 
                                    id="setWeekBtn" class="btn btn-success">Add Fixture</button>
                            </div>
                        </li>
                    </ul> 
                </div>
            </div>
        ';
    }

    $content = '
        <link rel="stylesheet" href="public/assets/libs/datetimepicker/picker.css" />
        <div id="dtBox"></div>
        <div class="mainWrapper push-f-t">
            <div class="pageHeader">
                <div class="row align-items-center">
                    <div class="col-3"><div class="backNav d-flex align-items-center justify-content-center bg-light rounded border-1">Back</div></div>
                    <div class="col-9"><div id="logo" class="d-flex align-items-center">MERRY GLOBAL</div></div>
                </div>
            </div>

            <div class="pageBody push-f-t push-f-b">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">'.$bals.'</div>
                    </div>
                </div>
            </div>
        </div>

        <script type="text/javascript" src="public/assets/libs/datetimepicker/picker.js"></script>
    ';

    // render the page content 
    print $templates->renderPage(['{{title}}', '{{content}}'], ['Merry Global - Set Week', $content], 'mainlayout.php');