<?php

$content = '
    <div class="container-fluid p-3">

        <a href="menus" class="backNav d-flex align-items-center justify-content-center">Menu</a>

        <div class="row">
            <div class="col-12 col-sm-6 col-md-6">
                <div class="mainNavs d-flex justify-content-center align-items-center"><a href="admin_agent" class=" d-flex justify-content-center align-items-center flex-column text-white bg-primary border border-1 border-primary"><i class="ri ri-user-2-fill"></i><span>All Agents</span></a></div>
            </div>

            <div class="col-12 col-sm-6 col-md-6">
                <div class="mainNavs d-flex justify-content-center align-items-center"><a href="admin_agent" class=" d-flex justify-content-center align-items-center flex-column text-white bg-primary border border-1 border-primary"><i class="ri ri-user-2-fill"></i><span>All Agents Reports</span></a></div>
            </div>
        </div>
    </div>
';


// render the page content 
print $templates->renderPage(['{{title}}', '{{content}}'], ['Meri Global - Menu', $content], 'mainlayout.php');
