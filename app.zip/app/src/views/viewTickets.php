<?php
    $lists = '';
    if(isset($_GET['id']) && !empty($_GET['id'])) {
        $id = filter_var($_GET['id'], FILTER_SANITIZE_STRING);
        $id = mysqli_real_escape_string($functions->con, $functions->hashing('decrypt', $id));
    }
    $statement = ' `parent_id` = "'.$id.'" ';
    $query = $functions->select('ticket', $statement);
    if(!empty($query)) {
        foreach ($query as $key => $value) {
            $lists .= '<li class="list-group-item text-center ">
                         <!--<p class="text-muted">'.$functions->filter_output($value['ticket_no']). '</p>-->
                         <h4 class="">'.$functions->filter_output($value['winning_numbers']). '</h4>
                         <p class="mb-0">
                            Date: '.date('d/m/Y', strtotime($functions->filter_output($value['date_created']))). '<br>
                            Amount: &#8358;'.$functions->filter_output($value['amount']). '
                         </p>
                       </li>';
        }
    }

    $content = '
        <div class="container-fluid">
            <a href="menus" class="backNav d-flex align-items-center justify-content-center">Menu</a>

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header"><h3 class="card-title text-center mb-0">Ticket List</h3></div>
                        <ul class="list-group list-group-flush">'.$lists.'</ul> 
                    </div>
                </div>
            </div>
        </div>
    ';

    // render the page content 
    print $templates->renderPage(['{{title}}', '{{content}}'], ['Meri Global - View Ticket', $content], 'mainlayout.php');