<?php

    if(isset($_GET['wid']) && !empty($_GET['wid'])) {

        $id = filter_var($_GET['wid'], FILTER_SANITIZE_STRING);
        $id = $functions->hashing('decrypt', $id);

        $numbers = $data = $heading = '';
        $alias     = ' `r`.*, `w`.*, `s`.* ';
        $join      = ' AS `w` LEFT JOIN `results` AS `r` ON `r`.`week_id` = `w`.`weeks_id` 
                       JOIN `season` AS `s` ON `s`.`season_id` = `w`.`season_id` ';
        $statement = ' `w`.`weeks_id` = "'.mysqli_real_escape_string($functions->con, $id).'" LIMIT 1';
        $query = $functions->join_select('weeks', $alias, $join, $statement);
        if(!empty($query)) {
            $heading = $functions->filter_output($query[0]['week_title']);
            $numbers = '';
            $data .= "<div class='row'><div class='col-5 fw-bold text-uppercase'>Season:</div><div class='col-7 text-end' style='font-size: 18px;'>".$functions->filter_output(ucwords($query[0]['season_name']))."</div></div>";
            $data .= "<div class='row'><div class='col-5 fw-bold text-uppercase'>Week:</div><div class='col-7 text-end' style='font-size: 18px;'>".$functions->filter_output(ucwords($query[0]['week_title']))."</div></div>";
            $data .= "<div class='row'><div class='col-5 fw-bold text-uppercase'>Date:</div><div class='col-7 text-end' style='font-size: 18px;'>".$functions->filter_output(ucwords($query[0]['season_name']))."</div></div>";
            $data .= "<div class='row'><div class='col-5 fw-bold text-uppercase'>Draw <br>Number:</div><div class='col-7 text-end fw-bold' style='font-size: 18px;'>".$functions->filter_output(str_replace(',', ', ', $query[0]['numbers']))."</div></div>";
        }

        $content = '

            <div class="container-fluid">

                <a href="menus" class="backNav d-flex align-items-center justify-content-center">Menu</a>

                <div class="row">
                    <div class="col-12">
                        <div class="card shadow">
                            <div class="card-header text-center"><h2 class="card-title mb-0">'.ucwords($heading).'</h2></div>
                            <div class="card-body">
                                '.$data.'
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        ';

        // render the page content 
        print $templates->renderPage(['{{title}}', '{{content}}'], ['Meri Global - Win confirm ', $content], 'mainlayout.php');

    }