<?php
    $bals = '';
    if(isset($_GET['id'])) {
        $id = filter_var($_GET['id'], FILTER_SANITIZE_STRING);
        // check if session is admin
        $alias = " s.*, `s`.`season_id` AS `seasonID`, w.*, f.* ";
        $join = " AS `w` join `season` AS `s` ON `s`.`season_id` = `w`.`season_id` 
                  left join `fixtures` AS `f` ON `f`.`season_id` = `w`.`season_id` AND `f`.`week_id` = `w`.`weeks_id`
        ";
        $statement = " `w`.`weeks_id` = '{$id}' ";

        $query = $functions->join_select("weeks", $alias, $join, $statement);
        if(!empty($query))
        {
            $btnStatus = ' data-status="set" ';
            $btnTxt = 'Set Fixtures';
            $bals .= '
                <div class="card mb-3 shadow-sm">
                    <div class="card-header"><h4 class="card-title mb-0">Set Fixtures: '.$functions->filter_output($query[0]['week_title']).'</h4></div>
                    <div class="card-body pt-1 pb-1">
                        <ul class="list-group list-group-flush mb-0">
            ';
                $num = 49;
                $port = 0;
                for($i = 1; $i <= $num; $i++) {
                    $v = '';
                    $fixture_id = ' data-fixtureid="" ';
                    if(!empty($query[$port]['start_time'])) {
                        $v = $query[$port]['start_time'];
                        $btnStatus = ' data-status="update" ';
                        $fixture_id = ' data-fixtureid="'.$query[$port]['fixture_id'].'"';
                        $btnTxt = 'Update Fixtures';
                    }
                    $balUI = '<span class="numbers_balls active" style="margin: 0px;"><span class="ballText">'.$i.'</span></span>';
                    $bals .= '
                        <li class="list-group-item pe-0 ps-0">
                            <div class="input-group mb-0 input-group-sm">
                                <span class="input-group-text">'.$balUI.'</span>
                                <input type="text" class="form-control form-control-sm" name="gameTime[]" 
                                       value="'.$v.'" id="game_id_'.$i.'" placeholder="Set date & time" 
                                       style="cursor: pointer" 
                                       '.$fixture_id.'
                                       data-field="datetime" data-format="dd-MMM-yyyy hh:mm:ss AA" required readonly>
                            </div>
                        </li>
                    ';

                    $port++;
                }
            $bals .= '
                            <li class="list-group-item pe-0 ps-0">
                                <div class="d-grid">
                                    <button type="button" 
                                        data-week="'.$functions->filter_output($query[0]['weeks_id']).'" 
                                        data-season="'.$functions->filter_output($query[0]['seasonID']).'" 
                                        id="sFBtn" '.$btnStatus.' class="btn btn-success">'.$btnTxt.'</button>
                                </div>
                            </li>
                        </ul> 
                    </div>
                </div>
            ';
        }


    }

    $content = '
        <style>
            .numbers_balls .ballText {
                line-height: 35px;
            }
        </style>
        <link rel="stylesheet" href="public/assets/libs/datetimepicker/picker.css" />
        <div id="dtBox"></div>
        
        <div class="container-fluid">

            <a href="menus" class="backNav d-flex align-items-center justify-content-center">Menu</a>

            <div class="row">
                <div class="col-12">'.$bals.'</div>
            </div>
        </div>

        <script type="text/javascript" src="public/assets/libs/datetimepicker/picker.js"></script>
    ';

    // render the page content 
    print $templates->renderPage(['{{title}}', '{{content}}'], ['Meri Global - Set Fixtures', $content], 'mainlayout.php');