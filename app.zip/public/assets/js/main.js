"use strict";
// make requests
function makeRequest(dataString, param) {
  let request = $.ajax({
    url: param + ".php",
    type: "POST",
    data: dataString,
    cache: false,
    processData: false,
    contentType: false,
    dataType: "json",
  });
  return request;
}

function makeRequest2(dataString, param) {
  let request = $.ajax({
    url: param + ".php",
    type: "POST",
    data: dataString,
    cache: false,
    dataType: "json",
  });
  return request;
}

// modal pop up
function modalRequest(content) {
  let modalContent = document.getElementById("modal-dialog");
  const modal_init = new bootstrap.Modal(
    document.getElementById("modal_container"),
    {
      backdrop: "static",
      keyboard: true,
      show: true,
      focus: true,
    }
  );
  modal_init.toggle();
  return (modalContent.innerHTML = content);
}

function setCookie(cname, cvalue, exdays) {
  const d = new Date();
  d.setTime(d.getTime() + exdays * 24 * 60 * 60 * 1000);
  let expires = "expires=" + d.toUTCString();
  // document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";

  // let obj = {};

  // // converting javascript object to JSON string
  // const jsonString = JSON.stringify(cookieObj);

  // create the cookie
  document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

// datetime picker
$(document).ready(function () {
  $("#dtBox").DateTimePicker({
    dateFormat: "MM-dd-yyyy",
    timeFormat: "HH:mm",
    dateTimeFormat: "MM-dd-yyyy HH:mm:ss AA",
  });
});

// create a session for the pos
$(document).on("submit", "#add_pos", function (e) {
  e.preventDefault();
  let form = $(this);
  let btn = form.find("#btn");
  let pos_id = form.find("#pos_id");
  let pos_imei = form.find("#imei");
  let password = form.find("#password");
  let url = form.attr("action");

  // check if values are empty
  if (pos_id.val() !== "" && pos_imei.val() !== "" && password.val() !== "") {
    const cookieObj = [
      {
        posID: pos_id.val(),
        imei: pos_imei.val(),
        password: password.val(),
      },
    ];

    // converting javascript object to JSON string
    // const jsonString = JSON.stringify(cookieObj);

    $.post(
      url + ".php",
      { jsonData: JSON.stringify(cookieObj) },
      function (data, textStatus, jqXHR) {
        if (data["response"] === "1") {
          form[0].reset();
          window.location.reload();
        } else {
          alert(data["output"]);
        }
      },
      "json"
    );
  }
});

/*

$(document).on('submit', '#add_pos', function (e) {
  e.preventDefault();
  let form = $(this);
  let btn = form.find('#btn');
  let pos_id = form.find('#pos_id');
  let pos_imei = form.find('#imei');
  let url = form.attr('action');
  
  // check if values are empty
  if(pos_id.val() !== '' && pos_imei.val() !== '') 
  {
    form.serialize();
    let formdata = new FormData(form[0]);
    // Make an ajax call
    let ajaxCal = makeRequest(formdata, url);
    $.when(ajaxCal).then(
      function successHandler(response) {
        if (response.response == '1') {
          form[0].reset();
          window.location.reload();
        }
        // modalRequest(response.output);
      }
    ).always(function completeHandler() {
        btn.html('Add Terminal').removeAttr('disabled').removeClass('disabled');
    });
  }
})

*/

// the login system
$(document).on("submit", "#login", function (e) {
  e.preventDefault();
  let form = $(this);
  let url = form.attr("action");
  let username = form.find("#username");
  let password = form.find("#password");
  let pos_number = form.find("#pos");
  let pos_id = form.data("pos");
  let posVal = form.find("#cookie_id").val();

  if (username.val() == "" || pos_number.val() == "" || password.val() == "") {
    alert("all fields are required");
  } else {
    const obj = [
      {
        pos_id: pos_number.val(),
        username: username.val(),
        password: password.val(),
      },
    ];

    if (pos_id == posVal && pos_id !== "" && posVal !== "") {
      // converting javascript object to JSON string
      // const jsonString = JSON.stringify(cookieObj);

      $.post(
        url + ".php",
        { jsonData: JSON.stringify(obj) },
        function (data, textStatus, jqXHR) {
          if (data["response"] === "1") {
            form[0].reset();
            alert(data["output"]);
            window.location.reload();
          } else {
            alert(data["output"]);
          }
        },
        "json"
      );
    } else {
      alert(
        "Sorry terminal cannot be authenticated. please contact administrators for more information"
      );
    }
  }
});

// declaring default values for the games
let gamesArray = [];
const $checks = $('input[name^="numbers"]');
const $gameMenus = $("#gameMenus");
const $gameMenusLists = $("#gameMenusLists");

// shuffle game / auto pick function
function shuffle() {
  const arr = [];
  $.each($('input[isactive="true"]'), function () {
    // add the number to the array
    arr.push($(this).val());
  });

  let i = arr.length,
    j = 0,
    temp;
  while (i--) {
    j = Math.floor(Math.random() * (i + 1));
    temp = arr[i];
    arr[i] = arr[j];
    arr[j] = temp;
  }

  let game = $gameMenus.find("option:selected").val();
  if (game === "nap") {
    let count = $gameMenusLists.find("option:selected").data("id");

    // spliting the array and limit it to a certain number
    let sliced = arr.splice(j, count).sort(function (a, b) {
      return a - b;
    });

    let balls = "";
    // uncheck all checked boxes
    $checks.prop("checked", false);
    for (let i = 0; i < sliced.length; i++) {
      // check the once with the matched numbers
      balls += `<div class="show-balls-child">${sliced[i]}</div>`;
      $(document)
        .find("#label_" + sliced[i])
        .addClass("active")
        .hide();
      $('input[id="numbers_' + sliced[i] + '"]').prop("checked", true);
    }

    $("#show-balls").html(balls);

    // clearing the array
    arr, (sliced = []);
  }
  $("#amount_input").removeAttr("disabled").val("");
}

function getOptions(e) {
  const selectBox = $("#" + e);
  const opt_val = selectBox.find("option:selected").val();
  return opt_val;
}

// function for game selection menu
function gameSelection(param) {
  if (param === "nap") {
    return $checks.filter(":checked").length;
  } else if (param === "perm") {
    return $checks.filter(":checked").length;
  }
}

// selecting the menu options
$(function () {
  $gameMenus.on("change", function () {
    const optionsArray = [];
    let options = $(this).find("option:selected").val();

    $checks.prop("checked", false);

    if (options === "nap" || options === "perm") {
      optionsArray.push("3", "4", "5", "6");
    }
    if (optionsArray.length > 0) {
      let i, len;
      let optionsLists = "";
      let arrayLen = optionsArray.length;
      for (i = 0, len = arrayLen; i < len; i++) {
        optionsLists += `<option value="${options}${optionsArray[i]}" data-id="${optionsArray[i]}">${options}${optionsArray[i]}</option>`;
      }

      // The targeted element
      $gameMenusLists.html(optionsLists);
      // clear selection display
      $("#show-balls").html("");
    }
  });
});

//counting check boxes when checked
$(function () {
  $checks.change(function (e) {
    e.preventDefault();
    let checkbox = $(this);
    let counter = $checks.filter(":checked").length;
    let selection = $gameMenusLists.find("option:selected").data("id");
    let gameType = $gameMenus.find("option:selected").val();
    let amount_input = $("#amount_input");

    let labels = $(document).find("#label_" + checkbox.val());

    if (checkbox.prop("checked") == true) {
      if (gameType === "nap") {
        if (counter > selection) {
          checkbox.prop("checked", false).removeClass("active");
          alert(
            `Maximum of ${selection} numbers are required for ${gameType}-${selection}`
          );
          return;
        }
      }
      labels.addClass("active");
    }

    let checkedOptions = [];
    $.each($('input[name^="numbers"]:checked'), function () {
      // add the number to the array
      checkedOptions.push($(this).val());
    });

    let balls = "";
    let sliced = checkedOptions.splice(0);
    for (let i = 0; i < sliced.length; i++) {
      // check the once with the matched numbers
      balls += `<div class="show-balls-child">${sliced[i]}</div>`;
    }

    // check if the user make a pick
    if (counter <= 2) {
      // enable the amount input
      amount_input.attr("disabled", true).addClass("disabled");
    } else {
      // enable the amount input
      amount_input.removeAttr("disabled").removeClass("disabled");
    }

    $("#show-balls").html(balls);
  });
});

// run the calculation for perm lines
function check_number_of_lines(type_of_game, expected_number) {
  // getting the total number count of game selected
  const $selection_count = gameSelection(type_of_game);

  // alert('game = ' + type_of_game +' expected = '+ expected_number +' total=' + $selection_count)

  // the expected number of game to win
  if (type_of_game === "nap" || type_of_game === "perm") {
    // alert($selection_count + ' ' + expected_number);
    // run condition if perm is selected
    if (type_of_game === "perm") {
      // calculate backwards
      let $calculateReverse = multiply(
        calculateLinesBackwards(expected_number, $selection_count)
      );
      // calculate forwards
      let $calculateForward = multiply(
        calculateLinesForward(expected_number, $selection_count)
      );

      const $total_line = Math.floor($calculateReverse / $calculateForward);
      return $total_line;
    }

    return 0;
  }
}

// run the calculation Backwards
function calculateLinesBackwards(expected_number, games_selected) {
  const ourArray = [];
  const remainder = Math.floor(games_selected - expected_number);
  for (let i = games_selected; i > remainder; i--) {
    ourArray.push(i);
  }
  return ourArray;
}

// run the calculation forward
function calculateLinesForward(expected_number, games_selected) {
  const ourArray = [];
  for (let i = 1; i <= expected_number; i++) {
    ourArray.push(i);
  }
  return ourArray;
}

// multiplying array numbers
function multiply($array) {
  let total = 1;
  for (let i = 0; i < $array.length; i++) {
    total = total * $array[i];
  }
  return total;
}

// Add game functionality
$(function () {
  $(document).on("click", 'button[id^="addGame"]', function (e) {
    e.preventDefault();
    let gameType = $gameMenus.find("option:selected").val();
    let gameLists = $gameMenusLists.find("option:selected").val();
    let amount_input = $("#amount_input");
    let checkoutBtn = $("#checkout");

    // disable the amount input
    amount_input.attr("disabled", true).addClass("disabled");

    if (gameType === "nap" || gameType === "perm") {
      // get the total number of perm or nap selected
      let expected_numbers = $gameMenusLists.find("option:selected").data("id");

      // run if the condition is matched
      let checkedOptions = [];
      // check and count all checked inputs
      $.each($('input[name^="numbers"]:checked'), function () {
        // add the number to the array
        checkedOptions.push($(this).val());
      });

      // check if the user make a pick
      if (checkedOptions.length <= 0) {
        alert("You have not selected your picks");
        return;
      }

      if (gameType === "nap") {
        // checking if the game selection matches the game option
        if (`${gameType}${gameSelection(gameType)}` !== gameLists) {
          alert(
            `You have to select total of ${expected_numbers} numbers for ${gameType}-${expected_numbers}`
          );
          return;
        }
      }

      // 1. check the number of line returned from function
      // of a selected matches
      const $num_of_lines = check_number_of_lines(gameType, expected_numbers);

      let permission = 0;

      // if amount was inserted run code
      if (amount_input.val() !== "" && amount_input.val() !== false) {
        // default amount per game
        let amount = 100;
        let $amountPerLine = 0;
        if (amount == amount_input.val() || amount_input.val() > amount) {
          // Amount per game

          // 1. amount stack
          let $amountStack = amount_input.val();
          const $minimunAmount = 50;

          // check if the line return is greater than 0
          if ($num_of_lines <= 0) {
            if (gameType === "nap") {
              // set permission to 1
              permission = 1;
            }
          } else {
            if (gameType === "perm") {
              // formula for amount on lines

              // 2. divide the amount statck with number of lines
              $amountPerLine = Math.floor($amountStack / $num_of_lines);
              if ($amountPerLine < $minimunAmount) {
                bootbox.alert({
                  message: `Minimum amount of &#8358;${Math.floor(
                    $minimunAmount * $num_of_lines
                  )} stack is required for ${$num_of_lines} lines with (&#8358;${$minimunAmount}) per line
                            `,
                  backdrop: true,
                  className: "animate__slideInDown animate__animated",
                });

                amount_input.removeAttr("disabled").removeClass("disabled");
                return;
              }

              if ($num_of_lines > 1) {
                if ($amountStack < Math.floor($minimunAmount * $num_of_lines)) {
                  // alert(`Minimum of ${Math.floor($minimunAmount * $num_of_lines)} is required to play this game`);
                  bootbox.alert({
                    message: `Minimum of ${Math.floor(
                      $minimunAmount * $num_of_lines
                    )} is required to play this game`,
                    backdrop: true,
                    className: "animate__slideInDown animate__animated",
                  });
                  return;
                }
              }
            }

            // set permission to 1
            permission = 1;
          }

          // check if permission is set to 1
          if (permission === 1) {
            // counting the total arrays
            const counts = gamesArray.push({
              selected: checkedOptions,
              amount: $amountStack,
              amount_per_line: $amountPerLine,
              lines: $num_of_lines,
              game_type: gameType,
              game_selection: gameType + "-" + expected_numbers,
            });
            // displaying the array count
            checkoutBtn.find("span").text(`${counts}`);
            // clear the selection
            $checks.prop("checked", false);
            // clear the selections
            $("#show-balls").html("");
            // reset the amount input and disable it
            amount_input.val("100");
            amount_input.attr("disabled", true).addClass("disabled");
          }
        } else {
          bootbox.alert({
            message: "Minimun of &#8358;" + amount + " is required",
            backdrop: true,
            className: "animate__slideInDown animate__animated",
          });
        }
      } else {
        // alert("Amount has not been added.");
        bootbox.alert({
          message: "Amount has not been added.",
          backdrop: true,
          className: "animate__slideInDown animate__animated",
        });
        amount_input.removeAttr("disabled").removeClass("disabled");
        return;
      }
    }
  });
});

// checkout
$(function () {
  $(document).on("click", 'button[id^="checkout"]', function (e) {
    e.preventDefault();

    let btn = $(this);
    const wrapper = $("#printer_wrap");

    // check for queued
    if (gamesArray.length < 1) {
      alert("You have an empty selection");
      return;
    }
    // show loading button
    btn.html(`<span class="spinner-border spinner-border-sm"></span> wait..`);

    $.post(
      "public/parser/send_game.php",
      { jsonData: JSON.stringify(gamesArray) },
      function (data, textStatus, jqXHR) {
        if (data["response"] === "1") {
          gamesArray = [];
          wrapper.html(data["output"]);
          // show modal
          // modalRequest(data['output'])

          // clear the button counter
          btn.find("span").html("");

          // print the game
          PrintElem("printer_wrap");
          wrapper.html("");
        } else {
          alert(data["output"]);
        }
        // replace the btn html content
        btn
          .html(
            `<span class="badge rounded-pill bg-light text-secondary fw-bolder"></span> Checkout`
          )
          .removeAttr("disabled");
      },
      "json"
    );
  });
});

// print the game
function PrintElem(elem) {
  var mywindow = window.open("", "PRINT", "height=auto,width=auto");

  mywindow.document.write(
    `<!DOCTYPE html><html lang="en">
      <head><title> Print </title><meta name="viewport" content="width=device-width, initial-scale=1.0">
      <style type="text/css">
        @media print {
          body {background: white;font-size: 12pt;padding: 0;margin: 0;}
          #ticket > .ticket_header { position: relative;}
          #ticket > .ticket_header #ticket_header_img {text-align: center;}
          #ticket > .ticket_header h1 {display: block; font-size: 20pt; font-family: "courier"; font-weight: bold; text-align: center;}
          #ticket > .ticket_header h2 {display: block; font-size: 16pt; font-family: "courier"; font-weight: bold; text-align: center;}
          #ticket > .ticket_header h3 {display: block; font-size: 14pt; font-family: "courier"; font-weight: bold; text-align: center;}
          #ticket > .sub_ticket_header{position: relative; margin-bottom: 0px; padding: 5px;}
          #ticket > .sub_ticket_header:after {content: "";display: table;clear: both;width: 100%;}
          #ticket > .sub_ticket_header > div > span {float: left; width: 50%; font-size: 12pt; font-family: "courier";}
          #ticket > .sub_ticket_header > div > span:first-child {font-weight: bold; text-align: left;}
          #ticket > .sub_ticket_header > div > span:last-child {text-align: right;}
          #ticket,#ticket > .ticket_child,#ticket > .ticket_child > .ticket_desc {position: relative;}
          #ticket > .ticket_child > .ticket_desc {margin-bottom: 12pt; padding: 5px;}
          #ticket > .ticket_child > .ticket_desc:after {content: "";display: table;clear: both;width: 100%;}
          #ticket > .ticket_child > .ticket_desc > span {float: left;width: 40%;font-size: 12pt;font-family: "courier";text-align: center;color: #000;}
          #ticket > .ticket_child > .ticket_desc span:first-child {width: 40%;text-align: left;}
          #ticket > .ticket_child > .ticket_desc span:last-child {width: 20%;}
          #ticket > .ticket_child .ticket_num_lists {text-align: center;font-family: "courier";font-weight: bold;font-size: 12pt;color: #000;margin: 20pt 0;}
          #ticket > .ticket_child >.ticket_amt {text-align: center;font-weight: bold;font-family: "courier";margin-top: 20pt;}
          #ticket > .ticket_child >.lines {text-align: center;font-family: "courier";margin-bottom: 20pt;}
          #ticket > .total_amt {   text-align: center; font-weight: bold; font-size: 14pt; font-family: "courier";}
          #ticket > .centered { display: block; margin-top: 15pt; margin-bottom: 15pt; font-size: 10pt; text-align: center; }
      }</style>`
  );
  mywindow.document.write(`</head><body>`);
  mywindow.document.write(document.getElementById(elem).innerHTML);
  mywindow.document.write(`</body></html>`);

  mywindow.document.close(); // necessary for IE >= 10
  mywindow.focus(); // necessary for IE >= 10*/

  mywindow.print();
  mywindow.close();

  return true;
}

// adding a season
$(function () {
  $(document).on("submit", "#addseason_form", function (e) {
    e.preventDefault();
    let form = $(this);
    let season_name = form.find("#season_name");
    let start_date = form.find("#start_date");
    let end_date = form.find("#end_date");
    let status = form.find("#status");
    let week_prefix = form.find("#week_prefix");
    let week_count = form.find("#week_count");
    let btn = form.find("#seasonBtn");

    let dataParse = [];

    if (
      season_name.val() == "" ||
      start_date.val() == "" ||
      end_date.val() == "" ||
      status.val() == "" ||
      week_prefix.val() == "" ||
      week_count.val() == ""
    ) {
      bootbox.alert("All fields are required.");
      return;
    } else {
      // add the values into an array
      dataParse.push({
        season_name: season_name.val(),
        start_date: start_date.val(),
        end_date: end_date.val(),
        status: status.val(),
        week_prefix: week_prefix.val(),
        week_count: week_count.val(),
      });

      // show loading button
      btn.html(`<span class="spinner-border spinner-border-sm"></span> wait..`);

      $.post(
        "public/parser/addSeason.php",
        { jsonData: JSON.stringify(dataParse) },
        function (data, textStatus, jqXHR) {
          if (data["response"] === "1") {
            dataParse = [];
            // show modal
            bootbox.alert(data["output"]);
            // reset the form
            form[0].reset();
          } else {
            alert(data.output);
          }
          // replace the btn html content
          btn.html(`Create Season`).removeAttr("disabled");
        },
        "json"
      );
    }
  });
});

// set time of play and fixtures
$(function () {
  $(document).on("click", "#sFBtn", function (e) {
    e.preventDefault();

    let btn = $(this);
    let season_id = btn.data("season");
    let week_id = btn.data("week");
    let statues = btn.data("status");

    let gameTime = [];
    let inputTime = [];
    let fixtureID = [];
    $('input[name^="gameTime"]').each(function () {
      inputTime.push($(this).val());
      fixtureID.push($(this).data("fixtureid"));
    });

    // button value
    let button_txt = "";
    if (statues === "set") {
      button_txt += "Set Fixtures";
    } else {
      button_txt += "Update Fixtures";
    }

    // Check for empty fields
    if (jQuery.inArray("", inputTime) !== -1) {
      alert("An empty date and time was found.");
    } else {
      // loading btn
      btn
        .html(
          '<span class="spinner-border spinner-border-sm"></span> Please wait..'
        )
        .attr("disabled", true);

      gameTime.push({
        games: inputTime,
        fixtureid: fixtureID,
        season_id: season_id,
        week_id: week_id,
        status: statues,
      });

      $.post(
        "public/parser/addFixtures.php",
        { jsonData: JSON.stringify(gameTime) },
        function (data, textStatus, jqXHR) {
          alert(data["output"]);
          btn.html(`${button_txt}`).removeAttr("disabled");

          if (data["response"] === "1" || data["response"] === "0") {
            gameTime = [];
            window.location.reload();
          }
        },
        "json"
      );
    }
  });
});

// filter date input for report
function filterDate(textbox, container) {
  let input = $("#" + textbox);
  let wrapper = $("#" + container);
  if (input.val() !== "" || input.val() !== "undefined") {
    let arr_value = [{ val: input.val() }];
    $.post(
      "public/parser/sales_report.php",
      { jsonData: JSON.stringify(arr_value) },
      function (data, textStatus, jqXHR) {
        if (data["response"] === "1") {
          arr_value = [];
          wrapper.html(data["output"]);
        } else {
          bootbox.alert({
            message: data["output"],
            backdrop: true,
            className: "animate__slideInDown animate__animated",
          });
        }
      },
      "json"
    );
  }
}

// add agents
$(
  (function () {
    $(document).on("submit", "#addagent_form", function (e) {
      e.preventDefault();
      let form = $(this);
      let agent_name = form.find("#agent_name");
      let agent_no = form.find("#agent_no");
      if (agent_name.val() == "" || agent_no.val() == "") {
        alert("Sorry both fields are required");
      } else {
        let arr_value = [{ name: agent_name.val(), agent_no: agent_no.val() }];
        $.post(
          "public/parser/addagent.php",
          { jsonData: JSON.stringify(arr_value) },
          function (data, textStatus, jqXHR) {
            if (data["response"] === "1") {
              arr_value = [];

              bootbox.alert({
                message: data["output"],
                backdrop: true,
                className: "animate__slideInDown animate__animated",
              });

              // reset the form
              form[0].reset();
            } else {
              bootbox.alert({
                message: data["output"],
                backdrop: true,
                className: "animate__slideInDown animate__animated",
              });
            }
          },
          "json"
        );
      }
    });

    // delete an agent
    $(document).on("click", 'button[id^="remove_agent_"]', function (e) {
      e.preventDefault();
      let btn = $(this);
      let id = btn.data("id");
      if (id !== "") {
        let arr_value = [{ id: id }];
        $.post(
          "public/parser/delete_agent.php",
          { jsonData: JSON.stringify(arr_value) },
          function (data, textStatus, jqXHR) {
            if (data["response"] === "1") {
              arr_value = [];

              bootbox.alert({
                message: data["output"],
                backdrop: true,
                className: "animate__slideInDown animate__animated",
              });

              $(document)
                .find("tr#" + id)
                .remove();
            }
          },
          "json"
        );
      }
    });
  })()
);

// set seasons as active
// set week
$(
  (function () {
    // set season
    $(document).on("click", 'button[id^="setSeason"]', function (e) {
      e.preventDefault();
      let btn = $(this);
      let id = btn.data("id");
      if (id !== "") {
        let arr_value = [{ id: id }];
        $.post(
          "public/parser/set_season.php",
          { jsonData: JSON.stringify(arr_value) },
          function (data, textStatus, jqXHR) {
            if (data["response"] === "1") {
              arr_value = [];

              alert(data["output"]);
              window.location.reload();
            } else {
              bootbox.alert({
                message: data["output"],
                backdrop: true,
                className: "animate__slideInDown animate__animated",
              });
            }
          },
          "json"
        );
      }
    });

    // set week
    $(document).on("click", 'button[id^="setWeek"]', function (e) {
      e.preventDefault();
      let btn = $(this);
      let id = btn.data("id");
      if (id !== "") {
        let arr_value = [{ id: id }];
        $.post(
          "public/parser/set_week.php",
          { jsonData: JSON.stringify(arr_value) },
          function (data, textStatus, jqXHR) {
            if (data["response"] === "1") {
              arr_value = [];

              alert(data["output"]);
              window.location.reload();
            } else {
              bootbox.alert({
                message: data["output"],
                backdrop: true,
                className: "animate__slideInDown animate__animated",
              });
            }
          },
          "json"
        );
      }
    });

    // search ticket
    $(document).on("click", 'button[id="srTicket"]', function (e) {
      e.preventDefault();
      let btn = $(this);
      let url = btn.data("url");
      let textval = $("#textbox");
      let box = $("#result");

      if (textval.val() !== "") {
        box.addClass("d-none").find(".card-body").html("");
        let arr_value = [{ data: textval.val() }];
        $.post(
          "public/parser/" + url + ".php",
          { jsonData: JSON.stringify(arr_value) },
          function (data, textStatus, jqXHR) {
            if (data["response"] === "1") {
              arr_value = [];
              box.removeClass("d-none");
              box.find(".card-body").html(data["output"]);
              textval.val("");
            } else {
              bootbox.alert({
                message: data["output"],
                backdrop: true,
                className: "animate__slideInDown animate__animated",
              });
            }
          },
          "json"
        );
      }
    });
  })()
);
