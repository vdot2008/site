<?php

    $ts = gmdate("D, d M Y H:i:s") . " GMT";
    header('Expires: Sat, 26 Jul 1997 05:00:00 GMT');
    header("Last-Modified: $ts");
    header("Cache-Control: no-store, no-cache, must-revalidate");
    header("Cache-Control: post-check=0, pre-check=0", false);
    header("Pragma: no-cache");
    
    // apcu_clear_cache();

    require_once dirname(__DIR__, 1)."/app/require.php";
    $session->start();

    # Path to the templates
    $file = '';
    $paths = DIR_NAME . '/app/src/views/';
    $error_file = $paths . strtolower('404.php');

    # Get the url from the parameter
    $router_file = $routerClass->geturl();

    // 1. check if there is a pos session set 
    $pos_status = $session->getCookie('posID');
    if(empty($pos_status)) {
        require DIR_NAME . '/app/src/views/create.php';
        return;
    }
    // check for the login session
    elseif (!empty($session->getCookie('posID')) 
        && empty($session->getSession('pos_agent', 'agent_no'))) {
        require DIR_NAME . '/app/src/views/login.php';
        return;
    }
    else {
        if (!empty($router_file)) {
            // run if session pos_on is true
            $request = $router_file[0];
            switch ($request) {
                case '/':
                case '':
                    // if no session was set create a pos in the database and assign the user
                    require $paths.$request.'.php';
                    break;

                case 'main':
                    require $paths.$request.'.php';
                    break;

                case 'menus':
                    require $paths.$request.'.php';
                    break;

                case 'confirm_wins':
                    require $paths.$request.'.php';
                    break;

                case 'add_season':
                    require $paths.$request.'.php';
                    break;

                case 'setWeek':
                    require $paths.$request.'.php';
                    break;

                case 'seasons':
                    require $paths.$request.'.php';
                    break;

                case 'seasons_weeks':
                    require $paths.$request.'.php';
                    break;

                case 'weeks_fixtures':
                    require $paths.$request.'.php';
                    break;

                case 'week_detail':
                    require $paths.$request.'.php';
                    break;

                case 'set_fixtures':
                    require $paths.$request.'.php';
                    break;

                case 'viewTickets':
                    require $paths.$request.'.php';
                    break;

                case 'reports':
                    require $paths.$request.'.php';
                    break;

                case 'create':
                    require $paths.$request.'.php';
                    break;

                case 'agent':
                    require $paths.$request.'.php';
                    break;

                case 'add_agent':
                    require $paths.$request.'.php';
                    break;

                case 'all_agent':
                    require $paths.$request.'.php';
                    break;  

                case 'search':
                    require $paths.$request.'.php';
                    break;

                case 'settings':
                    require $paths.$request.'.php';
                    break;  

                default:
                    http_response_code(404);
                    require $paths.'404.php';
                    break;
            }
        }

        // if the path is empty
        if (empty($router_file)) {
            require $paths.'menus.php';
        }
    }
