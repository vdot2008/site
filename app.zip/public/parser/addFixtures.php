<?php
    // load the require file from controllers folder
    require_once dirname(__DIR__, 2)."/app/require.php";

    /* * set content type */
    $functions->content_type("application/json");
    $resp = [];

    $data = json_decode($_POST['jsonData']);
    if(!empty($data)) {

        // Run if the status is create
        // db table name
        $table = 'fixtures';
        if($data[0]->status === 'set')
        {
            $fixtures_array = [];
            foreach ($data as $key => $data_values) {
                $rowNum = 1;
                for($i = 0; $i < count($data_values->games); $i++) {
                    array_push($fixtures_array, array(
                            "row_number"    => $rowNum,
                            "start_time"    => mysqli_real_escape_string($functions->con, $data_values->games[$i]),
                            "season_id"     => mysqli_real_escape_string($functions->con, $data_values->season_id),
                            "week_id"       => mysqli_real_escape_string($functions->con, $data_values->week_id),
                            "date_created"  => date("Y-m-d h:i:s"),
                            "status"        => ''
                        )
                    );
                    $rowNum++;
                }
            };

            // the array keys to be parsed to the db
            $weeks_keys = ["row_number", "start_time" , "season_id", "week_id", "date_created", "status"];
            // insert multiple into the database 
            $insertWeeks = $functions->multiple_insert($table, $weeks_keys, $fixtures_array);
            if(!empty($insertWeeks)) {
                $resp = ['response' => '1', 'output' =>  ' fixtures was set successfully'];
                print json_encode($resp);
                return;
            }
        }


        // Run line of code if the status is update
        if($data[0]->status === 'update')
        {
            $reponse = [];
            foreach ($data as $key => $data_values) {
                for($i = 0; $i < count($data_values->games); $i++) {
                    // the db row id
                    $db_row_id = mysqli_real_escape_string($functions->con, $data_values->fixtureid[$i]);
                    // param to set the db
                    $param = array(
                        "start_time"    => mysqli_real_escape_string($functions->con, $data_values->games[$i])
                    );
                    // Conditon for the update staement
                    $statement = ' `fixture_id` = "'.$db_row_id.'" ';
                    // executing the update statement
                    $update = $functions->update($table, $statement, $param);
                    if(!empty($update)) {
                        $reponse[] = 1;
                    }
                }
            };

            if(!empty($reponse)) {
                $resp = ['response' => '1', 'output' => 'Week fixture has been updated successfully'];
                print json_encode($resp);
                return;
            }
        }

    }
    else {
        $resp = ['response' => '0', 'output' => 'No queued game on list'];
        print json_encode($resp);
        return;
    }