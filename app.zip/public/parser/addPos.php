<?php
    // load the require file from controllers folder
    require_once dirname(__DIR__, 2)."/app/require.php";

    /* * set content type */
    $functions->content_type("application/json");
    $resp = [];

    $data = json_decode($_POST['jsonData']);

    $pos_id = filter_var($data[0]->posID, FILTER_SANITIZE_STRING);
    $imei = filter_var($data[0]->imei, FILTER_SANITIZE_STRING);
    $password = filter_var($data[0]->password, FILTER_SANITIZE_STRING);

    //check the parsed values
    if(!empty($pos_id) && !empty($imei) && !empty($password))
    {
        // check for the pos
        $checkPos = $functions->check_db('pos', ['pos_no' => $pos_id], '', '');
        if(empty($checkPos)) {
            // insert to the database
            $param = [
                'pos_no' => mysqli_real_escape_string($functions->con, $pos_id),
                'imei' => mysqli_real_escape_string($functions->con, $imei),
                'password' => mysqli_real_escape_string($functions->con, $functions->hashing('encrypt', $password)),
                'log_status' => 'on',
                'date_created' => date('Y-m-d h:i:s'),
            ];
            $insert = $functions->insert('pos', $param);
        }

        // set cookie
        setcookie('posID', $pos_id, time() + (86400 * 30), "/");

        $resp = ['response' => '1'];
        print json_encode($resp);
        return;
        
    }
    else 
    {
        $resp = ['response' => '0', 'output' => 'Both fields are rquired'];
        print json_encode($resp);
        return;
    }