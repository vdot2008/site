<?php
    // load the require file from controllers folder
    require_once dirname(__DIR__, 2)."/app/require.php";

    /* * set content type */
    $functions->content_type("application/json");
    $resp = [];

    $data = json_decode($_POST['jsonData']);
    if(count($data) >= 1) {
        $season_name    = filter_var($data[0]->season_name, FILTER_SANITIZE_STRING);
        $start_date     = filter_var($data[0]->start_date, FILTER_SANITIZE_STRING);
        $end_date       = filter_var($data[0]->end_date, FILTER_SANITIZE_STRING);
        $week_prefix    = filter_var($data[0]->week_prefix, FILTER_SANITIZE_STRING);
        $week_count     = filter_var($data[0]->week_count, FILTER_SANITIZE_STRING);

        //check the parsed values
        if(!empty($season_name) && !empty($start_date) && !empty($end_date) && !empty($week_prefix) && !empty($week_count))
        {
            // check for the pos
            $checkSeason = $functions->check_db('season', ['start_year' => $start_date, 'end_year' => $end_date], '', 'OR');
            if(empty($checkSeason)) {
                // check if start date is lower to the end date
                $statement = " `end_year` < '".mysqli_real_escape_string($functions->con, $start_date)."' AND `status` = 'active' ";
                $check = $functions->select('season', $statement);
                if(!empty($check))
                {
                    $resp = ['response' => '0', 'output' => 'Cannot create another season , until the current season is over'];
                    print json_encode($resp);
                    return;
                }
                // parameter array to send to season table
                $param = [
                    'season_name' => mysqli_real_escape_string($functions->con, $season_name),
                    'date_create' => date('Y-m-d h:i:s'),
                    'status' => 'inactive',
                    'start_year' => mysqli_real_escape_string($functions->con, $start_date),
                    'end_year' => mysqli_real_escape_string($functions->con, $end_date)
                ];
                $insert = $functions->insert('season', $param);
                if(!empty($insert)) {
                    // looping for the number of week created
                    $weeks_array = [];
                    $txt = '';
                    for($i = 1; $i <= $week_count; $i++) {
                        $status = 'inactive';
                        // if($i == 1) {
                        //     $status = 'active';
                        // }
                        // adding values to the array
                        array_push($weeks_array, array(
                                            "week_title"=> $week_prefix.' '. $i,
                                            "date_created"=>date("Y-m-d h:i:s"),
                                            "season_id"=> $insert,
                                            "status" => $status
                                        )
                        );
                    }
                    // the array keys to be parsed to the db
                    $weeks_keys = ["week_title", "date_created" , "season_id", "status"];
                    // insert multiple into the database 
                    $insertWeeks = $functions->multiple_insert('weeks', $weeks_keys, $weeks_array);
                    if(!empty($insertWeeks)) {
                        $resp = ['response' => '1', 'season' => $season_name, 'output' =>  $season_name.' was added successfully'];
                        print json_encode($resp);
                        return;
                    }
                }  
            }
            else {
                $resp = ['response' => '1', 'output' => 'A season with a start year or end year already exist.'];
                print json_encode($resp);
                return;
            }
        }
        else 
        {
            $resp = ['response' => '0', 'output' => 'Both fields are rquired'];
            print json_encode($resp);
            return;
        }
    }
    