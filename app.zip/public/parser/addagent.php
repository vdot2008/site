<?php
    // load the require file from controllers folder
    require_once dirname(__DIR__, 2)."/app/require.php";

    /* * set content type */
    $functions->content_type("application/json");
    $resp = [];

    $data = json_decode($_POST['jsonData']);
    if(count($data) > 0) {
        $agent_name    = filter_var($data[0]->name, FILTER_SANITIZE_STRING);
        $agent_no      = filter_var($data[0]->agent_no, FILTER_SANITIZE_STRING);

        //check the parsed values
        if(!empty($agent_name) && !empty($agent_no))
        {
            // check for the pos
            $check = $functions->check_db('users', ['agent_no' => $agent_no], '', 'OR');
            if(empty($check)) {
                // insert into the db
                $param = [
                    'agent_name' => mysqli_real_escape_string($functions->con, $agent_name),
                    'agent_no' => mysqli_real_escape_string($functions->con, $agent_no),
                    'status' => 'active',
                    'date_create' => date('Y-m-d h:i:s'),
                ];
                $insert = $functions->insert('users', $param);
                if(!empty($insert)) {
                    $resp = ['response' => '1', 'output' => 'Agent ('.$agent_no.') was created successfully'];
                        print json_encode($resp);
                        return;
                    }
            }
            else {
                $resp = ['response' => '0', 'output' => 'An agent with agent no ('.$agent_no.') already exists.'];
                print json_encode($resp);
                return;
            }
        }
        else 
        {
            $resp = ['response' => '0', 'output' => 'Both fields are rquired'];
            print json_encode($resp);
            return;
        }
    }
    