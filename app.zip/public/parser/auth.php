<?php
    // load the require file from controllers folder
    require_once dirname(__DIR__, 2)."/app/require.php";

    /* * set content type */
    $functions->content_type("application/json");
    $resp = [];

    $data = json_decode($_POST['jsonData']);
    $pos_id = filter_var($data[0]->pos_id, FILTER_SANITIZE_STRING);
    $username = filter_var($data[0]->username, FILTER_SANITIZE_STRING);
    $password = filter_var($data[0]->password, FILTER_SANITIZE_STRING);

    //check the parsed values
    if(!empty($username) && !empty($password) && !empty($pos_id))
    {
        $check_pos = $functions->check_db('pos', array("pos_no" => $pos_id, "password" => $functions->hashing('encrypt', $password)), '', 'and');
        if(empty($check_pos))
        {
            $resp = ['response' => '0', 'output' => 'Pos no and password combination is wrong.'];
            print json_encode($resp);
            return;
        }
        else {
            // check for the user and start a session
            $check_agent = $functions->check_db('users', array("agent_no" => $username), '', '');
            if(empty($check_agent)) {
                $resp = ['response' => '0', 'output' => 'Unknown Agent username was provided'];
                print json_encode($resp);
                return;
            }
            else 
            {
                $statement = " `agent_no` = '$username' LIMIT 1";
                $query = $functions->select('users', $statement);
                if(!empty($query)) {

                    # Session values
                    $session->setSession('pos_agent', array(
                        'id' => $functions->filter_output($query[0]['agent_id']),
                        'name' => $functions->filter_output($query[0]['agent_name']),
                        'agent_no' => $functions->filter_output($query[0]['agent_no']),
                        'pos_id' => $functions->filter_output($pos_id),
                        'status' => 'active'
                    ));

                    $resp = ['response' => '1', 'output' => 'Welcome Agent' . $functions->filter_output($query[0]['agent_no'])];
                    print json_encode($resp);
                    return;
                }
            }
        }
        // 
        /*
        // insert to the database
        $param = [
            'pos_no' => mysqli_real_escape_string($functions->con, $pos_id),
            'imei' => mysqli_real_escape_string($functions->con, $imei),
            'log_status' => 'on',
            'date_created' => date('Y-m-d h:i:s'),
        ];
        $insert = $functions->insert('pos', $param);
        if(!empty($insert)) {
            // set cookie
            setcookie('posID', $pos_id, time() + (86400 * 30), "/");

            $resp = ['response' => '1', 'output' => $pos_id . ' ' .$imei];
            print json_encode($resp);
            return;
        }

        */
    }
    else 
    {
        $resp = ['response' => '0', 'output' => 'Username and Password are rquired.'];
        print json_encode($resp);
        return;
    }