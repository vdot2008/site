<?php
    // load the require file from controllers folder
    require_once dirname(__DIR__, 2)."/app/require.php";

    /* * set content type */
    $functions->content_type("application/json");
    $resp = [];

    $data = json_decode($_POST['jsonData']);
    if(count($data) > 0) {
        $id    = filter_var($data[0]->id, FILTER_SANITIZE_STRING);

        //check the parsed values
        if(!empty($id))
        {
            // check for the pos
            $id = mysqli_real_escape_string($functions->con, $id);
            $statement = " `agent_id` = '{$id}' ";
            $check = $functions->select('users', $statement);
            if(!empty($check)) {
                // delete data
                $delete = $functions->delete('users', $statement);
                if(!empty($delete)) {
                    $resp = ['response' => '1', 'output' => 'Agent was removed successfully'];
                        print json_encode($resp);
                        return;
                    }
            }
            else {
                $resp = ['response' => '0', 'output' => 'No row affected'];
                print json_encode($resp);
                return;
            }
        }
    }
    