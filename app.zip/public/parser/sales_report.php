<?php
    // load the require file from controllers folder
    require_once dirname(__DIR__, 2)."/app/require.php";

    /* * set content type */
    $functions->content_type("application/json");
    $resp = $amount = [];

    $data = json_decode($_POST['jsonData']);
    if(!empty($data[0]->val)) {
        $date = filter_var($data[0]->val, FILTER_SANITIZE_STRING);
        $date = date("Y-m-d", strtotime($date));

        // query the database 
        $statement = " `date_created` LIKE '%$date%' ";
        $query = $functions->select('ticket', $statement);
        if(!empty($query)) {
            foreach($query as $values) {
                if(date('Y-m-d', strtotime($values['date_created'])) === $date) {
                    array_push($amount, $values['amount']);
                }
            }

            $t_amt = 0;
            if(!empty($amount)) {
                $t_amt = array_sum($amount);
            }

            $resp = [
                'response' => '1', 
                'output' => '
                    <div class="row">
                        <div class="col-5"><h4>Sales Date:</h4></div>
                        <div class="col-7 text-end text-success" style="font-size: 20px;"><i class="ri ri-calendar-check-fill"></i> '.$date.'</div>
                    </div>
                    <div class="row">
                        <div class="col-5"><h4>Total:</h4></div>
                        <div class="col-7 text-end text-success" style="font-size: 20px;">&#8358;'.number_format($t_amt, 0).'</div>
                    </div>
            '];
            print json_encode($resp);
            return;
            
        }
        else {
            $resp = ['response' => '0', 'output' => 'No record was found for the provided date '.filter_var($data[0]->val, FILTER_SANITIZE_STRING)];
            print json_encode($resp);
            return;
        }
    }
    else {
        $resp = ['response' => '0', 'output' => 'Empty date was parsed'];
        print json_encode($resp);
        return;
    }