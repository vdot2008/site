<?php
    // load the require file from controllers folder
    require_once dirname(__DIR__, 2)."/app/require.php";

    /* * set content type */
    $functions->content_type("application/json");
    $resp = [];

    $data = json_decode($_POST['jsonData']);
    if(!empty($data[0]->data)) {
        $txt = filter_var($data[0]->data, FILTER_SANITIZE_STRING);

        // query the database 
        $statement = " `ticket_no` = '".mysqli_real_escape_string($functions->con, $txt)."' LIMIT 1 ";
        $query = $functions->select('ticket', $statement);
        if(!empty($query)) {

            $output = '
                <a href="viewTickets?id='.$functions->hashing('encrypt', $functions->filter_output($query[0]['ticket_id'])).'" class="d-flex align-items-center justify-content-center">
                    <div class="btn-group btn-group-sm">
                        <button type="button" class="btn btn-success btn-sm p-1 pt-0 pb-0"><i class="ri ri-newspaper-fill"></i></button>
                    </div>
                    <p class="ps-3 mb-0"><small class="text-muted">Ticket#</small>'.$functions->filter_output($query[0]['ticket_no']).'</p>
                </a>
            ';

            $resp = ['response' => '1', 'output' => $output];
            print json_encode($resp);
            return;
            
        }
        else {
            $resp = ['response' => '0', 'output' => 'No record was found'];
            print json_encode($resp);
            return;
        }
    }