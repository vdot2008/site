<?php
    // load the require file from controllers folder
    require_once dirname(__DIR__, 2)."/app/require.php";

    /* * set content type */
    $functions->content_type("application/json");
    $resp = [];

    $data = json_decode($_POST['jsonData']);
    if(!empty($data)) {
        // check if the agent session array is empty
        if(!empty($session->getSession('pos_agent'))){
            // check for season
            $alias = ' `s`.*, `w`.*';
            $join  = ' AS `s` JOIN `weeks` AS `w` ON `s`.`season_id` = `w`.`season_id` AND `w`.`status` = "active" ';
            $statement = ' `s`.`status` = "active" LIMIT 1';
            $query = $functions->join_select('season', $alias, $join, $statement);
            if(!empty($query))
            {
                // Generate and check for the ticket id
                // Generating a ticket id automatically
                $ticketID = $functions->check_and_generate_id('ticket', 'ticket_no', 6);
                // Session Agent's details
                $agent_name   = $session->getSession('pos_agent', 'name');
                $agent_no     = $session->getSession('pos_agent', 'agent_no');            
                $agent_pos    = $session->getSession('pos_agent', 'pos_id');     
                $agent_tbl_id = $session->getSession('pos_agent', 'id');
                $ticket_id    = $ticketID.strtotime(date('d-m-y h:i:s a'));
                $weekId       = $query[0]['weeks_id'];
                $seasonId     = $query[0]['season_id'];
                $date_created = date("Y-m-d h:i:s");

                // db table name
                $table = 'ticket';

                $amount_played = $gameType = $gameTypeSelection = $numbers = '';
                $template = '<table><tbody>';
                $i = 0;
                $insert = $templateHeader = '';
                $amount = [];
                foreach ($data as $key => $data_values) {
                    $amount_played     = $data[$key]->amount;
                    $gameType          = $data[$key]->game_type;
                    $gameTypeSelection = $data[$key]->game_selection;
                    $numbers           = implode('  ,', $data[$key]->selected);
                    $total_amt         = array_push($amount, $amount_played);

                    if(!empty($data[$key]->lines)) {
                        $lines = $data[$key]->lines.'L';
                        $amount_per_line = '&#8358;'.$data[$key]->amount_per_line.' Per Line';
                    }
                    else {
                        $lines = $amount_per_line = '';
                    }
                    
                    // check for empty values
                    if(!empty($data[$key]->amount) && !empty($data[$key]->game_type) 
                        && !empty($data[$key]->game_selection) && !empty($data[$key]->selected)) {
                        // check if $i = 0;
                        // run database query
                        if($i === 0) {
                            $templateHeader = '
                                <div class="ticket_header">
                                    <div id="ticket_header_img"></div>
                                    <h1>MERRY GLOBAL BET</h1>
                                    <h2> Week - '.$weekId.'</h2>
                                    <h3>Ticket - '.$ticket_id.'</h3>
                                </div>
                                <div class="sub_ticket_header">
                                    <div id=""><span>Terminal : </span><span>'.$agent_pos.'</span></div>
                                    <div id=""><span>Season : </span><span>'.$seasonId.'</span></div>
                                    <div id=""><span>Date : </span><span>'.$date_created.'</span></div>
                                    <div id=""><span>Sales Date : </span><span>'.$date_created.'</span></div>
                                </div>
                            ';
                            $dbParam = [
                                "season_id"    => $seasonId,
                                "week_id"      => $weekId,
                                "ticket_no"    => $ticket_id,
                                "date_created" => $date_created,
                                "agent_id"     => $agent_tbl_id,
                                "pos_id"       => $agent_pos,
                                "ticket_type"  => 'parent'
                            ];
                            // insert to the db
                            $insert = $functions->insert($table, $dbParam);
                        }

                        if(!empty($insert)) {
                            // perform database commands
                            $param = [
                                "season_id" => $seasonId,
                                "week_id" => $weekId,
                                "parent_id" => $insert,
                                "amount"       => $amount_played,
                                "winning_numbers" => $numbers,
                                "ticket_type" => 'child',
                                "status" => '',
                                "date_created" => $date_created,
                                "agent_id" => $agent_tbl_id,
                                "pos_id" => $agent_pos,
                                "child_ticket_status" => ''
                            ];
                            // insert to the db
                            $db_insert = $functions->insert($table, $param);
                            if(!empty($db_insert)) {
                                // the ticket layout to be printed
                                $template .= '<div class="ticket_child"><div class="ticket_desc"><span>'.ucwords($data[$key]->game_selection).'</span><span>'.$amount_per_line.'</span><span>'.$lines.'</span></div><div class="ticket_num_lists">'.implode('  ,', $data[$key]->selected).'</div><div class="ticket_amt"> Stack: &#8358;'.$data[$key]->amount.'</div><div class="lines">--------------------------</div></div>';
                            }
                        }
                    }

                    // increase the number of $i
                    $i++;
                };

                // append the footer area of the ticket
                $tickets = $templateHeader . $template . '<div class="total_amt">Total Amount:'.array_sum($amount).'</div>';

                // render the page content 
                $getContent = $templates->renderPage(
                    ['{{title}}', '{{footer}}', '{{content}}'], 
                    ['Ticket Printing', 'Footer Area', $tickets], 
                    'ticketLayout.php');

                $resp = ['response' => '1', 'output' => $getContent];
                print json_encode($resp);
                return;
            }
            else {
                $resp = ['response' => '0', 'output' => 'No active season or week was found'];
                print json_encode($resp);
                return;
            }
        }
    }
    else {
        $resp = ['response' => '0', 'output' => 'No queued game on list'];
        print json_encode($resp);
        return;
    }