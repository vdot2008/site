<?php
    // load the require file from controllers folder
    require_once dirname(__DIR__, 2)."/app/require.php";

    /* * set content type */
    $functions->content_type("application/json");
    $resp = [];

    $data = json_decode($_POST['jsonData']);
    if(count($data) > 0) {
        $id    = filter_var($data[0]->id, FILTER_SANITIZE_STRING);

        //check the parsed values
        if(!empty($id))
        {
            $id = mysqli_real_escape_string($functions->con, $id);
            // check for the pos

            $statement = " `season_id` = '{$id}' LIMIT 1";
            $query = $functions->select("season", $statement);
            if(!empty($query)) {
                // insert into the db
                $status = $season = $query[0]['status'];
                if(strtolower($status) === strtolower('active'))
                {
                    $resp = ['response' => '0', 'output' => 'Season is currently active'];
                    print json_encode($resp);
                    return;
                }
                else 
                {
                    // update the current status
                    $update = $functions->update('season', " `status` = 'active' ", ['status' => 'inactive']);
                    if(!empty($update)) {
                        $setUpdate = $functions->update('season', $statement, ['status' => 'active']);
                        if(!empty($setUpdate)) {
                            // set week to inactive 
                            $update = $functions->update('weeks', " `status` = 'active' ", ['status' => 'inactive']);
                            $resp = ['response' => '1', 'output' => 'Season was set successfully'];
                            print json_encode($resp);
                            return;
                        }
                    }
                }
            }
            else {
                $resp = ['response' => '0', 'output' => 'Week cannot be found'];
                print json_encode($resp);
                return;
            }
        }
        else 
        {
            $resp = ['response' => '0', 'output' => 'invalid data was parsed'];
            print json_encode($resp);
            return;
        }
    }
    