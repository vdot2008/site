<?php
    // load the require file from controllers folder
    require_once dirname(__DIR__, 2)."/app/require.php";

    /* * set content type */
    $functions->content_type("application/json");
    $resp = [];

    $data = json_decode($_POST['jsonData']);
    if(count($data) > 0) {
        $id    = filter_var($data[0]->id, FILTER_SANITIZE_STRING);

        //check the parsed values
        if(!empty($id))
        {
            $id = mysqli_real_escape_string($functions->con, $id);
            // check for the pos

            $alias = " `s`.*, `s`.`status` AS `s_status`, `w`.* ";
            $join  = " AS `w` JOIN `season` AS `s` ON `s`.`season_id` = `w`.`season_id` ";
            $statement = " `w`.`weeks_id` = '{$id}' LIMIT 1";
            $query = $functions->join_select("weeks", $alias, $join, $statement);
            if(!empty($query)) {
                // insert into the db
                $status = $season = $query[0]['s_status'];
                if(strtolower($status) !== strtolower('active'))
                {
                    $resp = ['response' => '0', 'output' => 'Cannot set this week because week season is currently inactive'];
                    print json_encode($resp);
                    return;
                }
                else 
                {
                    $season_id = $query[0]['season_id'];
                    $statement = " `weeks_id` = '{$id}' ";

                    // update the current status
                    $update = $functions->update('weeks', " `status` = 'active' ", ['status' => 'inactive']);
                    if(!empty($update)) {
                        $functions->update('weeks', $statement, ['status' => 'active']);
                        $resp = ['response' => '1', 'output' => 'Week was set successfully'];
                        print json_encode($resp);
                        return;
                    }
                    
                }
            }
            else {
                $resp = ['response' => '0', 'output' => 'Week cannot be found'];
                print json_encode($resp);
                return;
            }
        }
        else 
        {
            $resp = ['response' => '0', 'output' => 'invalid data was parsed'];
            print json_encode($resp);
            return;
        }
    }
    