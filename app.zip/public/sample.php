<?php

    require_once dirname(__DIR__, 1)."/app/require.php";
    $session->start();

    # Path to the templates
    $file = '';
    $paths = DIR_NAME . '/app/src/views/';
    $error_file = $paths . strtolower('404.php');

    # Get the url from the parameter
    $router_file = $routerClass->geturl();

    print_r($router_file);

    // 1. check if there is a pos session set 
    $pos_status = $session->getCookie('posID');
    if(empty($pos_status)) {
        require DIR_NAME . '/app/src/views/create.php';
        return;
    }
    // check for the login session
    elseif (!empty($session->getCookie('posID')) 
        && empty($session->getSession('pos_agent', 'agent_no'))) {
        require DIR_NAME . '/app/src/views/login.php';
        return;
    }
    else {
        // run if session pos_on is true
        $request = $_SERVER['REQUEST_URI'];
        switch ($request) {
            case '/poolgame':
            case '/poolgame/':
                // if no session was set create a pos in the database and assign the user
                require DIR_NAME . '/app/src/views/menus.php';
                break;

            case '/poolgame/main':
                require DIR_NAME . '/app/src/views/main.php';
                break;

            case '/poolgame/confirm_wins':
                require DIR_NAME . '/app/src/views/confirm_wins.php';
                break;

            case '/poolgame/add_season':
                require DIR_NAME . '/app/src/views/add_season.php';
                break;

            case '/poolgame/setWeek':
                require DIR_NAME . '/app/src/views/setWeek.php';
                break;

            case '/poolgame/create':
                require DIR_NAME . '/app/src/views/aboutus.php';
                break;

            default:
                http_response_code(404);
                require DIR_NAME . '/app/src/views/404.php';
                break;
        }
    }
